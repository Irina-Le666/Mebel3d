# Мебель 3D — геометрическое ядро (core)
Чистая Java 17, без зависимостей от Android. Единицы — миллиметры.
Сборка и тесты (без Gradle):
  javac -d out src/main/java/mebel3d/core/Core.java src/test/java/mebel3d/core/CoreTest.java
  java -ea -cp out mebel3d.core.CoreTest
Состав: Box (SAT-пересечения, выход за стены), Part/Furniture (детали и изделия),
cabinet() (параметрический шкаф), bom() и materialAreaM2() (спецификация), Room/Opening (проёмы).
