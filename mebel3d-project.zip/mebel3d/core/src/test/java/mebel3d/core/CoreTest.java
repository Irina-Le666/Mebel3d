package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class CoreTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static void bad(Runnable r, String m) { n++; try { r.run(); } catch (IllegalArgumentException e) { return; } throw new AssertionError(m); }

    public static void main(String[] a) {
        Box s1 = new Box(0, 0, 1000, 1000, 0, 0, 500);
        ok(s1.overlaps(new Box(900, 0, 1000, 1000, 0, 0, 500)), "перекрытие");
        ok(!s1.overlaps(new Box(1000, 0, 1000, 1000, 0, 0, 500)), "касание не пересечение");
        ok(!s1.overlaps(new Box(0, 0, 1000, 1000, 0, 500, 500)), "разные высоты");
        ok(!s1.overlaps(new Box(1300, 0, 1000, 1000, 45, 0, 500)), "повёрнутый, зазор");
        ok(s1.overlaps(new Box(1100, 0, 1000, 1000, 45, 0, 500)), "повёрнутый, угол заходит");
        ok(new Box(1000, 1000, 800, 800, 0, 0, 100).insideRoom(5000, 3500), "внутри");
        ok(!new Box(300, 1000, 800, 800, 0, 0, 100).insideRoom(5000, 3500), "вышел за стену");
        ok(!new Box(400, 400, 1000, 400, 45, 0, 100).insideRoom(5000, 3500), "повёрнутый вышел углом");

        Furniture c = Core.cabinet("Шкаф", 1000, 550, 2100, 18, 3, "ЛДСП");
        ok(c.width() == 1000 && c.depth() == 550 && c.height() == 2100, "габариты шкафа");
        ok(c.selfIntersections().isEmpty(), "детали не пересекаются: " + c.selfIntersections());
        ok(c.parts().size() == 5 + 3, "число деталей");
        Furniture w = Core.cabinet("Шкаф", 1200, 550, 2100, 18, 3, "ЛДСП");
        ok(w.width() == 1200 && w.selfIntersections().isEmpty(), "изменение ширины перестроило детали");
        ok(w.parts().stream().filter(p -> p.name().equals("Полка")).allMatch(p -> p.w() == 1200 - 36), "полки подстроились");
        ok(w.parts().stream().filter(p -> p.name().startsWith("Боковина")).allMatch(p -> p.h() == 2100), "боковины не изменились");

        List<BomLine> b = Core.bom(c);
        ok(b.stream().filter(l -> l.name().equals("Боковина")).findFirst().get().qty() == 2, "боковины сгруппированы");
        ok(b.stream().filter(l -> l.name().equals("Полка")).findFirst().get().qty() == 3, "полки сгруппированы");
        ok(Core.materialAreaM2(c).containsKey("ХДФ"), "ХДФ в ведомости");

        bad(() -> Core.cabinet("x", 30, 500, 2000, 18, 0, "ЛДСП"), "слишком узкий шкаф");
        bad(() -> Core.cabinet("x", 1000, 500, 300, 18, 30, "ЛДСП"), "слишком много полок");
        bad(() -> new Part("p", 0, 10, 10, 0, 0, 0, "m"), "нулевая деталь");

        Furniture a1 = Core.cabinet("A", 1000, 500, 2000, 18, 1, "ЛДСП").moved(800, 400);
        Furniture a2 = Core.cabinet("B", 1000, 500, 2000, 18, 1, "ЛДСП").moved(1500, 400);
        Furniture a3 = a2.moved(1800, 400);
        ok(a1.box().overlaps(a2.box()), "шкафы пересекаются");
        ok(!a1.box().overlaps(a3.box()), "шкафы встык не пересекаются");

        Room r = new Room(5000, 3500, 2700, 100, List.of(new Opening(0, 500, 900, 2100, 0), new Opening(1, 1000, 1500, 1400, 900)));
        ok(r.validate().isEmpty(), "корректные проёмы");
        ok(!new Room(5000, 3500, 2700, 100, List.of(new Opening(0, 4500, 900, 2100, 0))).validate().isEmpty(), "проём за стеной");
        ok(!new Room(5000, 3500, 2700, 100, List.of(new Opening(1, 1000, 1500, 2000, 900))).validate().isEmpty(), "проём выше стены");
        ok(!new Room(5000, 3500, 2700, 100, List.of(new Opening(0, 500, 900, 2100, 0), new Opening(0, 1000, 900, 2100, 0))).validate().isEmpty(), "проёмы пересеклись");
        System.out.println("OK, проверок: " + n);
    }
}
