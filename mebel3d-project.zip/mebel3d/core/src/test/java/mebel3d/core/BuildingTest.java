package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class BuildingTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static Project room(String name, double W, double D) { return new Project(name, new Room(W, D, 2700, 100, List.of()), List.of()); }
    public static void main(String[] a) {
        Building b = new Building("Квартира", List.of()).add(room("Кухня", 5000, 3500), 0, 0).add(room("Спальня", 3000, 3500), 5100, 0).add(room("Ванная", 2000, 2000), 0, 6000);
        ok(Math.abs(b.totalAreaM2() - (17.5 + 10.5 + 4)) < 1e-9, "площадь");
        ok(b.warnings().isEmpty(), "нет предупреждений: " + b.warnings());
        ok(b.neighbors().equals(List.of("Кухня — Спальня")), "соседи: " + b.neighbors());
        ok(!b.add(room("Кладовая", 1000, 1000), 4500, 3000).warnings().isEmpty(), "пересечение помещений");
        Building b2 = b.add(room("Кабинет", 3000, 3000), 0, 3600);
        ok(b2.neighbors().contains("Кухня — Кабинет"), "соседство по горизонтальной стене");
        Building r = Building.fromJson(b2.toJson());
        ok(r.equals(b2), "сохранение и загрузка квартиры");
        try { Building.fromJson("{\"rooms\":"); ok(false, ""); } catch (IllegalArgumentException e) { ok(true, ""); }

        Furniture c = Core.cabinet("Шкаф", 1000, 550, 2100, 18, 3, "ЛДСП");
        String svg = Drawing.furniture(c);
        ok(svg.contains("1000 мм") && svg.contains("2100 мм") && svg.contains("550 мм"), "размеры на чертеже изделия");
        ok(svg.split("class=\"part\"", -1).length - 1 == 3 * c.parts().size(), "три вида всех деталей");
        ok(svg.contains("Полка ×3") && svg.contains("Боковина ×2"), "спецификация на чертеже");
        System.out.println("OK, проверок: " + n);
    }
}
