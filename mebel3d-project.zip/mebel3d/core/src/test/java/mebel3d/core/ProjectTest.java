package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class ProjectTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    public static void main(String[] a) {
        Room room = new Room(5000, 3500, 2700, 100, List.of(new Opening(0, 500, 900, 2100, 0), new Opening(1, 1000, 1500, 1400, 900)));
        Furniture sofa = Core.cabinet("Шкаф", 1000, 550, 2100, 18, 3, "ЛДСП").moved(600, 300);
        Furniture far = Core.cabinet("Тумба", 450, 400, 500, 18, 0, "ЛДСП").moved(2500, 1750);
        Project p0 = new Project("Кухня \"гостиная\"", room, List.of(sofa, far));

        Project.History h = new Project.History(p0);
        h.apply(p0.replace(0, sofa.moved(1000, 300)));
        h.apply(h.current().remove(1));
        ok(h.current().items().size() == 1, "удалено");
        ok(h.undo() && h.current().items().size() == 2, "отмена удаления");
        ok(h.undo() && h.current().items().get(0).x() == 600, "отмена перемещения");
        ok(!h.undo(), "дальше отменять нечего");
        ok(h.redo() && h.current().items().get(0).x() == 1000, "повтор");
        h.undo(); h.apply(p0.add(far.moved(100, 100)));
        ok(!h.redo(), "новая правка сбрасывает повтор");

        String js = p0.toJson();
        Project p1 = Project.fromJson(js);
        ok(p1.equals(p0), "сохранение и загрузка дают тот же проект");
        ok(p1.name().equals("Кухня \"гостиная\""), "кавычки в названии");
        try { Project.fromJson("{\"version\":1,"); ok(false, "нет ошибки"); } catch (IllegalArgumentException e) { ok(true, ""); }
        try { Project.fromJson("{\"version\":2,\"name\":\"x\"}"); ok(false, "нет ошибки"); } catch (IllegalArgumentException e) { ok(true, ""); }

        ok(p0.warnings().isEmpty(), "предупреждений нет: " + p0.warnings());
        ok(!p0.replace(0, sofa.moved(200, 300)).warnings().isEmpty(), "шкаф вышел за стену");
        ok(!p0.add(far.moved(2500, 1800)).warnings().isEmpty(), "две тумбы столкнулись");

        String plan = Drawing.plan(p0);
        ok(plan.contains("5000 мм") && plan.contains("3500 мм"), "размеры на плане");
        ok(plan.split("class=\"item\"", -1).length - 1 == 2 && plan.split("class=\"opening\"", -1).length - 1 == 2, "всё на плане");
        String e0 = Drawing.elevation(p0, 0);
        ok(e0.contains("class=\"item\"") && e0.split("class=\"item\"", -1).length - 1 == 1, "у стены 1 только шкаф");
        ok(e0.contains("class=\"opening\"") && e0.contains("5000 мм"), "проём и длина стены");
        ok(Drawing.elevation(p0, 1).contains("3500 мм") && !Drawing.elevation(p0, 1).contains("class=\"item\""), "у стены 2 мебели нет");
        System.out.println("OK, проверок: " + n);
    }
}
