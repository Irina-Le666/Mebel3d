package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class EditorTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    static Part find(Furniture f, String name, int k) { return f.parts().stream().filter(p -> p.name().equals(name)).skip(k).findFirst().get(); }

    public static void main(String[] a) {
        Furniture c = Core.cabinet("Шкаф", 1000, 550, 2100, 18, 3, "ЛДСП");

        Furniture t = Editor.resizePart(c, 0, 0, 36, false);
        ok(near(t.parts().get(0).w(), 36), "левая боковина толще");
        ok(near(find(t, "Низ", 0).x(), 36) && near(find(t, "Низ", 0).w(), 1000 - 54), "низ сжался между боковинами");
        ok(near(find(t, "Полка", 2).x(), 36) && near(find(t, "Полка", 2).w(), 946), "полки сжались");
        ok(near(find(t, "Боковина правая", 0).x(), 982), "правая боковина на месте");
        ok(near(t.width(), 1000) && t.selfIntersections().isEmpty(), "ширина прежняя, детали не пересекаются: " + t.selfIntersections());

        Furniture b = Editor.resizePart(c, 2, 2, 30, false);
        ok(near(find(b, "Низ", 0).h(), 30), "низ толще");
        ok(near(find(b, "Задняя стенка", 0).z(), 30) && near(find(b, "Задняя стенка", 0).h(), 2064 - 12), "задняя стенка укоротилась");
        ok(near(b.height(), 2100) && b.selfIntersections().isEmpty(), "высота прежняя: " + b.selfIntersections());

        Furniture u = Editor.resizePart(c, 3, 2, 30, true);
        ok(near(find(u, "Верх", 0).z(), 2070) && near(u.height(), 2100), "верх растёт вниз, высота прежняя");
        ok(near(find(u, "Задняя стенка", 0).h(), 2052) && u.selfIntersections().isEmpty(), "задняя стенка подстроилась");

        Furniture h = Editor.resizePart(c, 0, 2, 2400, false);
        ok(near(h.height(), 2400) && near(find(h, "Верх", 0).z(), 2082) && near(find(h, "Задняя стенка", 0).h(), 2064), "одна боковина выше: верх и задняя стенка не двигаются");
        Furniture st = Editor.resizePart(c, 2, 2, 100, false);
        ok(near(find(st, "Задняя стенка", 0).z(), 100) && near(st.height(), 2100), "утолщение низа до 100 мм");

        try { Editor.resizePart(c, 0, 0, 0, false); ok(false, "нулевой размер"); } catch (IllegalArgumentException e) { ok(true, ""); }
        try { Editor.resizePart(c, 0, 0, 2000, false); ok(false, "деталь схлопнулась"); } catch (IllegalArgumentException e) { ok(true, ""); }

        Room room = new Room(5000, 3500, 2700, 100, List.of());
        Project p = new Project("g", room, List.of(c.moved(1000, 1000), c.moved(2000, 1000), c.moved(4000, 3000)));
        Project m = Editor.moveItems(p, List.of(0, 1), 100, 200);
        ok(near(m.items().get(0).x(), 1100) && near(m.items().get(1).y(), 1200) && near(m.items().get(2).x(), 4000), "сдвиг группы");
        Project r = Editor.rotateItems(p, List.of(0, 1), 90);
        ok(near(r.items().get(0).x(), 1500) && near(r.items().get(0).y(), 500) && near(r.items().get(1).y(), 1500), "поворот группы вокруг центра");
        ok(near(r.items().get(0).rot(), 90) && near(r.items().get(2).rot(), 0), "поворот только группы");
        System.out.println("OK, проверок: " + n);
    }
}
