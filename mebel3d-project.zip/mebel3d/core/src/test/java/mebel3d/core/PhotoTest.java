package mebel3d.core;

import mebel3d.core.Core.*;
import mebel3d.core.Photos.*;
import java.util.*;

public class PhotoTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    static void bad(Runnable r, String m) { n++; try { r.run(); } catch (IllegalArgumentException e) { return; } throw new AssertionError(m); }

    public static void main(String[] a) {
        Controller c = new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        c.addPhoto("Стена с окном", "content://x/1");
        ok(c.photos().size() == 1 && !c.photos().get(0).calibrated() && !c.photos().get(0).bound(), "новое фото не откалибровано");
        c.addMark(0, "Окно", 300, 300, 800, 600);
        bad(() -> c.applyMark(0, 0), "без калибровки нельзя");
        c.calibratePhoto(0, 100, 500, 1100, 500, 2000);
        ok(near(c.photos().get(0).mmPerPx(), 2), "масштаб 2 мм на пиксель");
        bad(() -> c.applyMark(0, 0), "без привязки нельзя");
        c.bindPhoto(0, 0, 100, 900);
        c.applyMark(0, 0);
        Opening o = c.project().room().openings().get(0);
        ok(o.wall() == 0 && near(o.offset(), 400) && near(o.width(), 1000) && near(o.height(), 600) && near(o.sill(), 600), "окно из отметки: " + o);
        ok(c.project().room().validate().isEmpty(), "проём валиден");

        c.addMark(0, "Дверь", 1500, 100, 1950, 900);
        c.applyMark(0, 1);
        Opening d = c.project().room().openings().get(1);
        ok(near(d.sill(), 0) && near(d.height(), 1600) && near(d.offset(), 2800), "дверь от пола: " + d);
        c.addMark(0, "Дверь", 400, 100, 600, 900);
        bad(() -> c.applyMark(0, 2), "дверь пересекается с окном");
        c.addMark(0, "Дверь", 3000, 100, 3300, 900);
        bad(() -> c.applyMark(0, 3), "проём за пределами стены");

        c.addMark(0, "Розетка", 1200, 780, 1240, 820);
        c.applyMark(0, 4);
        Fixture f = c.project().fixtures().get(0);
        ok(f.kind().equals("Розетка") && near(f.x(), 2240) && near(f.y(), 25) && near(f.z(), 160) && near(f.w(), 80), "розетка у стены 1: " + f);
        bad(() -> Photos.fixtureFrom(c.photos().get(0), 0, c.project().room()), "окно не инженерный элемент");
        bad(() -> Photos.openingFrom(c.photos().get(0), 4, c.project().room()), "розетка не проём");

        c.bindPhoto(0, 1, 100, 900);
        c.addMark(0, "Радиатор", 300, 700, 800, 880);
        c.applyMark(0, 5);
        Fixture r = c.project().fixtures().get(1);
        ok(near(r.x(), 4975) && near(r.y(), 400 + 500) && near(r.w(), 50) && near(r.d(), 1000) && near(r.z(), 40) && near(r.h(), 360), "радиатор на стене 2: " + r);
        c.bindPhoto(0, 3, 100, 900); c.applyMark(0, 5);
        ok(near(c.project().fixtures().get(2).x(), 25), "стена 4 — у x=0");
        c.bindPhoto(0, 2, 100, 900); c.applyMark(0, 5);
        ok(near(c.project().fixtures().get(3).y(), 3475) && near(c.project().fixtures().get(3).x(), 900), "стена 3 — у y=D");

        bad(() -> c.addMark(0, "Рояль", 1, 1, 50, 50), "неизвестный тип");
        bad(() -> c.addMark(0, "Окно", 10, 10, 11, 11), "рамка мала");
        bad(() -> c.calibratePhoto(0, 5, 5, 6, 6, 1000), "точки близко");
        bad(() -> c.calibratePhoto(0, 0, 0, 100, 0, 0), "ноль мм");
        bad(() -> c.bindPhoto(0, 4, 1, 1), "стена 5");
        int marks = c.photos().get(0).marks().size();
        c.removeMark(0, 0);
        ok(c.photos().get(0).marks().size() == marks - 1, "отметка удалена");
        c.undo();
        ok(c.photos().get(0).marks().size() == marks, "отмена удаления отметки");

        Project p = c.project();
        ok(Project.fromJson(p.toJson()).equals(p), "фото сохраняются в проекте");
        String old = "{\"version\":1,\"name\":\"Старый\",\"room\":{\"W\":5000,\"D\":3500,\"H\":2700,\"wallT\":100,\"openings\":[]},\"items\":[]}";
        ok(Project.fromJson(old).photos().isEmpty(), "старый файл без фото открывается");
        c.removePhoto(0);
        ok(c.photos().isEmpty(), "фото удалено");
        System.out.println("OK, проверок: " + n);
    }
}
