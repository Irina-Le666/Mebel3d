package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class ControllerTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    public static void main(String[] a) {
        for (String name : Catalog.names()) {
            Furniture f = Catalog.create(name);
            ok(f.selfIntersections().isEmpty(), name + ": детали пересекаются " + f.selfIntersections());
            ok(!Core.bom(f).isEmpty() && Core.materialAreaM2(f).size() >= 1, name + ": спецификация");
            ok(Project.fromJson(new Project("p", new Room(5000, 3500, 2700, 100, List.of()), List.of(f)).toJson()).items().get(0).equals(f), name + ": сохранение");
        }
        Controller c = new Controller(new Project("Тест", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        c.add("Диван"); c.add("Стол");
        ok(c.project().items().size() == 2 && c.selected() == 1, "добавлено два, выбран последний");
        c.setPosition(1200, 1000);
        c.select(0); c.setPosition(3700, 3000);
        ok(c.hit(3700, 3000) == 0 && c.hit(1200, 1000) == 1 && c.hit(10, 10) == -1, "поиск предмета под точкой");
        ok(c.hit(3700 + 1190, 3000) == 0 && c.hit(3700 + 1210, 3000) == -1, "граница дивана 2400 мм");

        c.beginDrag(0, 3700, 3000);
        c.dragTo(3820, 2900, 50); c.dragTo(3913, 2812, 50);
        ok(near(c.project().items().get(0).x(), 3900) && near(c.project().items().get(0).y(), 2800), "перенос с привязкой 50 мм");
        c.endDrag();
        c.undo();
        ok(near(c.project().items().get(0).x(), 3700), "одна отмена возвращает перенос целиком");
        c.redo();
        ok(near(c.project().items().get(0).x(), 3900), "повтор");

        c.select(1); c.setSize(2000, 1000, 760);
        Furniture t = c.selectedItem();
        ok(near(t.width(), 2000) && near(t.depth(), 1000) && near(t.height(), 760), "стол масштабируется");
        c.add("Шкаф"); c.setSize(1200, 600, 2200);
        Furniture w = c.selectedItem();
        ok(near(w.width(), 1200) && near(w.height(), 2200) && w.selfIntersections().isEmpty() && near(w.parts().get(0).w(), 18), "шкаф пересобран, толщина прежняя");
        try { c.setSize(30, 600, 2200); ok(false, "слишком узкий"); } catch (IllegalArgumentException e) { ok(true, ""); }

        c.setPosition(100, 100);
        ok(c.warnings().stream().anyMatch(s -> s.contains("выходит")), "предупреждение о выходе за стены");
        c.setPosition(2500, 1200);
        int before = c.project().items().size();
        c.duplicate();
        ok(c.project().items().size() == before + 1 && c.selected() == before, "копия выбрана");
        c.deleteSelected();
        ok(c.project().items().size() == before && c.selected() == -1, "удаление");
        c.undo();
        ok(c.project().items().size() == before + 1, "отмена удаления");
        ok(Project.fromJson(c.toJson()).equals(c.project()), "проект сохраняется целиком");
        try { Catalog.create("Рояль"); ok(false, "нет изделия"); } catch (IllegalArgumentException e) { ok(true, ""); }
        System.out.println("OK, проверок: " + n);
    }
}
