package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class ConstructorTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    static Controller fresh() { return new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of())); }

    public static void main(String[] a) {
        Controller c = fresh();
        c.add("Панель"); c.setPosition(1000, 1000);
        ok(c.selectedItem().parts().size() == 1 && c.selectedPart() == -1, "новое изделие из одной панели");
        c.addPart("Боковина", 18, 400, 700, 0, 0, 18, "ЛДСП");
        Furniture f = c.selectedItem();
        ok(f.parts().size() == 2 && near(f.height(), 718) && near(f.width(), 600) && c.selectedPart() == 1, "добавлена деталь и выбрана");
        ok(near(f.x(), 1000) && f.selfIntersections().isEmpty(), "центр на месте, детали не пересекаются");
        c.addPart("Боковина", 18, 400, 700, 582, 0, 18, "ЛДСП");
        c.addPart("Бок", 18, 400, 700, 618, 0, 18, "ЛДСП");
        ok(near(c.selectedItem().width(), 636) && near(c.selectedItem().x(), 1018), "рост ширины: центр сдвинулся, деталь осталась на месте");

        Controller r = fresh();
        r.add("Панель"); r.setPosition(1000, 1000); r.setRotation(90);
        r.addPart("Бок", 18, 400, 100, 600, 0, 0, "ЛДСП");
        ok(near(r.selectedItem().x(), 1000) && near(r.selectedItem().y(), 1009), "поворот 90°: центр сдвигается вдоль повёрнутой оси");

        c.selectPart(2); c.removePart();
        ok(c.selectedItem().parts().size() == 3 && c.selectedPart() == -1, "деталь удалена");
        c.undo();
        ok(c.selectedItem().parts().size() == 4, "отмена удаления детали");
        c.selectPart(0); c.setPartPosition(-100, 0, 0);
        ok(near(c.selectedItem().parts().get(0).x(), 0) && near(c.selectedItem().width(), 736), "деталь влево: начало координат пересчитано");
        Controller one = fresh(); one.add("Панель"); one.selectPart(0);
        try { one.removePart(); ok(false, "последняя деталь"); } catch (IllegalArgumentException e) { ok(true, ""); }

        Controller k = fresh();
        k.add("Шкаф"); k.selectPart(0);
        k.setPartSize(0, 36, false);
        ok(!k.selectedItem().selfIntersections().isEmpty(), "несвязанная правка: детали наползли друг на друга");
        k.undo();
        k.selectPart(0); k.setPartSize(0, 36, true);
        ok(k.selectedItem().selfIntersections().isEmpty() && near(k.selectedItem().width(), 1000), "связанная правка: конструкция согласована");
        try { k.setPartSize(0, 0, true); ok(false, "нулевой размер"); } catch (IllegalArgumentException e) { ok(true, ""); }

        k.selectPart(1); int cnt = k.selectedItem().parts().size();
        k.duplicatePart(0, 0, 100);
        ok(k.selectedItem().parts().size() == cnt + 1 && k.selectedPart() == cnt, "копия детали выбрана");
        k.setPartMaterial("ЛДСП белый");
        ok(k.selectedPartItem().material().equals("ЛДСП белый"), "материал детали");
        try { k.setPartMaterial("Золото"); ok(false, "материал"); } catch (IllegalArgumentException e) { ok(true, ""); }
        k.select(0); k.selectPart(99);
        ok(k.selectedPart() == -1, "несуществующая деталь не выбирается");
        ok(Project.fromJson(k.toJson()).equals(k.project()), "проект с правленой мебелью сохраняется");
        System.out.println("OK, проверок: " + n);
    }
}
