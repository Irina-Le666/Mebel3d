package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class BlockTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    static void bad(Runnable r, String m) { n++; try { r.run(); } catch (IllegalArgumentException e) { return; } throw new AssertionError(m); }
    static Controller fresh() { return new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of())); }

    public static void main(String[] a) {
        // ---- группы ----
        Controller c = fresh();
        c.add("Шкаф"); c.setPosition(1000, 1000);
        c.add("Комод"); c.setPosition(2500, 1000);
        c.add("Стол"); c.setPosition(3500, 2500);
        c.toggleMulti(0); c.toggleMulti(1); c.groupMulti("Стена");
        ok(c.project().groupOf(0) == 0 && c.project().groupOf(1) == 0 && c.project().groupOf(2) == -1 && c.multi().isEmpty(), "группа создана");
        ok(c.project().membersOf(1).equals(List.of(0, 1)) && c.project().membersOf(2).equals(List.of(2)), "состав групп");
        c.beginDrag(0, 1000, 1000); c.dragTo(1300, 1200, 50); c.endDrag();
        ok(near(c.project().items().get(0).x(), 1300) && near(c.project().items().get(1).x(), 2800) && near(c.project().items().get(1).y(), 1200)
                && near(c.project().items().get(2).x(), 3500), "группа переносится целиком");
        c.undo();
        ok(near(c.project().items().get(1).x(), 2500), "перенос группы отменяется одним шагом");
        c.select(1); c.setPosition(2600, 1000);
        ok(near(c.project().items().get(0).x(), 1100), "ввод положения двигает всю группу");
        c.select(0); c.setRotation(90);
        ok(near(c.project().items().get(0).rot(), 90) && near(c.project().items().get(1).rot(), 90), "поворот группы");
        double cx = (c.project().items().get(0).x() + c.project().items().get(1).x()) / 2;
        ok(near(cx, 1850), "центр группы при повороте на месте");
        c.removeSelected();
        ok(c.project().groups().isEmpty() && c.project().items().size() == 2, "группа из одного изделия распадается");
        c.undo();
        ok(c.project().groups().size() == 1, "отмена удаления возвращает группу");
        c.select(0); c.ungroupSelected();
        ok(c.project().groups().isEmpty(), "разгруппировка");
        c.toggleMulti(1); c.toggleMulti(2); c.groupMulti("А"); c.toggleMulti(0); c.toggleMulti(1); c.groupMulti("Б");
        ok(c.project().groups().size() == 1 && c.project().membersOf(0).equals(List.of(0, 1)), "изделие уходит из старой группы");
        bad(() -> { c.toggleMulti(2); c.groupMulti("x"); }, "группа из одного");
        c.clearMulti();
        ok(Project.fromJson(c.toJson()).equals(c.project()), "группы сохраняются");
        Project old = Project.fromJson("{\"version\":1,\"name\":\"О\",\"room\":{\"W\":5000,\"D\":3500,\"H\":2700,\"wallT\":100,\"openings\":[]},\"items\":[]}");
        ok(old.groups().isEmpty(), "старый файл без групп");

        // ---- привязки ----
        Controller s = fresh(); s.add("Шкаф"); s.setPosition(1000, 1000);
        s.beginDrag(0, 1000, 1000); s.dragTo(530, 1000, 10); s.endDrag();
        ok(near(s.project().items().get(0).x(), 500), "левая грань прилипла к стене");
        s.beginDrag(0, 500, 1000); s.dragTo(4470, 1000, 10); s.endDrag();
        ok(near(s.project().items().get(0).x(), 4500), "правая грань прилипла к стене");
        Controller t = fresh(); t.add("Шкаф"); t.setPosition(1500, 1000); t.add("Шкаф"); t.setPosition(3500, 1000);
        t.beginDrag(1, 3500, 1000); t.dragTo(2530, 1000, 10);
        ok(near(t.project().items().get(1).x(), 2500), "грань прилипла к другому предмету");
        t.dragTo(2650, 1000, 10);
        ok(near(t.project().items().get(1).x(), 2650), "вне допуска привязки нет");
        t.endDrag();
        Controller g = fresh(); g.add("Шкаф"); g.setPosition(1500, 1000); g.add("Шкаф"); g.setPosition(2500, 1000);
        g.toggleMulti(0); g.toggleMulti(1); g.groupMulti("Г");
        g.beginDrag(1, 2500, 1000); g.dragTo(2540, 1000, 10); g.endDrag();
        ok(near(g.project().items().get(1).x(), 2540) && near(g.project().items().get(0).x(), 1540), "члены группы не липнут друг к другу");

        // ---- проёмы и инженерные элементы по выбору ----
        Controller o = fresh(); o.addOpening("Окно"); o.addOpening("Окно"); o.addFixture("Радиатор");
        o.selectOpening(0);
        ok(o.kind() == 2 && o.selectedOpening() != null, "выбран проём");
        o.updateOpening(0, 600, 1000, 1200, 800);
        ok(near(o.selectedOpening().offset(), 600) && near(o.selectedOpening().width(), 1000), "проём изменён");
        bad(() -> o.updateOpening(0, 4800, 1000, 1200, 800), "проём за стеной");
        bad(() -> o.updateOpening(0, 2000, 1500, 1400, 900), "проём наезжает на соседний");
        o.selectFixture(0);
        ok(o.kind() == 3 && o.selectedOpening() == null, "выбран элемент, проём снят");
        o.updateFixture(0, 3000, 50, 1200, 100, 100, 600);
        ok(near(o.selectedFixture().w(), 1200) && near(o.selectedFixture().x(), 3000), "элемент изменён");
        bad(() -> o.updateFixture(0, 3000, 50, 0, 100, 100, 600), "нулевая ширина");
        o.removeSelected();
        ok(o.project().fixtures().isEmpty() && o.kind() == 0, "элемент удалён");
        o.selectOpening(1); o.removeSelected();
        ok(o.project().room().openings().size() == 1, "проём удалён");
        o.undo(); o.undo();
        ok(o.project().room().openings().size() == 2 || o.project().fixtures().size() == 1, "отмена");
        o.add("Шкаф");
        ok(o.kind() == 1, "выбрано изделие");

        // ---- столкновения ----
        Controller k = fresh(); k.add("Шкаф"); k.setPosition(1000, 1000); k.add("Шкаф"); k.setPosition(1500, 1000); k.add("Стол"); k.setPosition(3500, 2500);
        ok(k.project().collidingItems().equals(Set.of(0, 1)), "столкнулись два шкафа");
        k.select(2); k.setPosition(100, 100);
        ok(k.project().collidingItems().equals(Set.of(0, 1, 2)), "стол вышел за стены");

        // ---- каталог и материалы ----
        ok(Catalog.search("ШКАФ", null).equals(List.of("Шкаф")), "поиск без учёта регистра");
        ok(Catalog.search("", "Сантехника").containsAll(List.of("Ванна", "Унитаз", "Тумба с раковиной")), "категория «Сантехника»");
        ok(Catalog.search("", null).size() == Catalog.names().size() && Catalog.search("рояль", null).isEmpty(), "пустой запрос и ненайденное");
        for (String nm : Catalog.names()) ok(Catalog.categories().contains(Catalog.category(nm)), nm + ": категория");
        ok(Catalog.categories().containsAll(List.of("Кухни", "Диваны и кресла", "Светильники")), "категории из ТЗ");
        ok(Materials.texture("ЛДСП дуб").equals("дерево") && Materials.texture("Ткань серый").equals("ткань") && Materials.texture("Металл").equals("гладкая"), "текстуры");
        Controller l = fresh(); l.addFixture("Светильник");
        ok(l.warnings().isEmpty(), "светильник под потолком не мешает");

        // ---- связанные помещения ----
        Room r1 = new Room(5000, 3500, 2700, 100, List.of(new Opening(1, 1000, 900, 2100, 0)));
        Room r2 = new Room(3000, 3500, 2700, 100, List.of(new Opening(3, 1200, 900, 2100, 0)));
        Building b = new Building("Кв", List.of()).add(new Project("Кухня", r1, List.of()), 0, 0).add(new Project("Спальня", r2, List.of()), 5100, 0);
        ok(b.passages().equals(List.of("Кухня ⇄ Спальня")), "проход через общую стену: " + b.passages());
        Building b2 = b.replace(1, new Project("Спальня", new Room(3000, 3500, 2700, 100, List.of(new Opening(3, 2800, 900, 2100, 0))), List.of()));
        ok(b2.passages().isEmpty(), "двери не совпадают по положению");
        double[] o3 = b.nextFreeOrigin(2000, 2000, 100);
        ok(near(o3[0], 8200) && near(o3[1], 0), "новая комната справа с зазором: " + Arrays.toString(o3));
        double[] o4 = b.add(new Project("Зал", new Room(7000, 3000, 2700, 100, List.of()), List.of()), 8200, 0).nextFreeOrigin(3000, 2000, 100);
        ok(near(o4[0], 0) && near(o4[1], 3600), "перенос на новую строку: " + Arrays.toString(o4));
        ok(b.remove(0).rooms().size() == 1 && near(b.move(1, 0, 4000).rooms().get(1).oy(), 4000), "удаление и перенос комнаты");
        String svg = Drawing.buildingPlan(b);
        ok(svg.split("class=\"room\"", -1).length - 1 == 2 && svg.contains("Кухня, 17.5 м²") && svg.contains("Спальня, 10.5 м²"), "план объекта");
        ok(Drawing.plan(new Project("п", r1, List.of())).contains("5000 мм"), "размерные линии на плане");
        ok(Drawing.elevation(new Project("п", r1, List.of()), 0).contains("2700 мм"), "высота на развёртке");
        System.out.println("OK, проверок: " + n);
    }
}
