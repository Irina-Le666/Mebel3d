package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class MaterialsTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    public static void main(String[] a) {
        for (String name : Catalog.names()) {
            Furniture f = Catalog.create(name);
            String d = Materials.dominant(f);
            ok(Materials.names().contains(d), name + ": материал " + d + " есть в справочнике");
        }
        Furniture c = Catalog.create("Шкаф");
        ok(Materials.dominant(c).equals("ЛДСП"), "основной материал шкафа");
        Furniture g = Materials.replaceMain(c, "ЛДСП графит");
        ok(g.parts().stream().filter(p -> p.name().equals("Задняя стенка")).allMatch(p -> p.material().equals("ХДФ")), "задняя стенка осталась из ХДФ");
        ok(g.parts().stream().filter(p -> !p.name().equals("Задняя стенка")).allMatch(p -> p.material().equals("ЛДСП графит")), "остальные детали из нового материала");
        ok(g.equals(c) == false && g.width() == c.width() && Core.bom(g).size() == Core.bom(c).size(), "геометрия и спецификация по деталям прежние");
        try { Materials.replaceMain(c, "Золото"); ok(false, "неизвестный материал"); } catch (IllegalArgumentException e) { ok(true, ""); }
        ok(Materials.color("ЛДСП белый") == 0xE9E5DF && Materials.color("нет такого") == 0xCCCCCC, "цвета");

        Controller k = new Controller(new Project("Т", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        k.add("Диван"); k.setMaterial("Ткань зелёный");
        ok(Materials.dominant(k.selectedItem()).equals("Ткань зелёный"), "материал через контроллер");
        k.undo();
        ok(Materials.dominant(k.selectedItem()).equals("Ткань"), "отмена смены материала");
        k.add("Шкаф"); k.add("Комод");
        String s = Drawing.specification(k.project());
        ok(s.contains("Спецификация: Т") && s.contains("Диван 2400×900×850 мм") && s.contains("Боковина ×2: 18×550×2100 ЛДСП"), "детали в спецификации");
        ok(s.contains("Ведомость материалов") && s.contains("ХДФ:") && s.contains("м²"), "ведомость материалов");
        System.out.println("OK, проверок: " + n);
    }
}
