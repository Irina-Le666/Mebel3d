package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

public class FixtureTest {
    static int n = 0;
    static void ok(boolean c, String m) { n++; if (!c) throw new AssertionError(m); }
    public static void main(String[] a) {
        Controller c = new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        ok(c.addOpening("Окно") && c.addOpening("Дверь") && c.project().room().openings().size() == 2, "окно и дверь добавлены");
        ok(c.project().room().validate().isEmpty(), "проёмы не пересекаются");
        int cnt = 2; while (c.addOpening("Окно")) cnt++;
        ok(cnt > 4 && c.project().room().validate().isEmpty(), "окна заполняют стены без пересечений, всего " + cnt);
        c.removeOpening(0);
        ok(c.project().room().openings().size() == cnt - 1, "проём удалён");

        Controller d = new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        d.addOpening("Дверь");
        d.setRoom(6000, 4000, 2500, 150);
        ok(d.project().room().W() == 6000 && d.project().room().H() == 2500 && d.project().room().openings().size() == 1, "размеры комнаты изменены, проём сохранён");
        d.undo();
        ok(d.project().room().W() == 5000, "отмена правки комнаты");
        try { d.setRoom(600, 4000, 2500, 150); ok(false, "проём не помещается"); } catch (IllegalArgumentException e) { ok(true, ""); }
        try { d.setRoom(5000, 3500, 2700, 2600); ok(false, "стены толще комнаты"); } catch (IllegalArgumentException e) { ok(true, ""); }

        Controller e = new Controller(new Project("К", new Room(5000, 3500, 2700, 100, List.of()), List.of()));
        e.addFixture("Колонна");
        e.add("Шкаф");
        e.setPosition(2500, 1750);
        ok(e.warnings().stream().anyMatch(s -> s.contains("мешает: Колонна")), "шкаф упёрся в колонну: " + e.warnings());
        e.setPosition(1000, 1000);
        ok(e.warnings().isEmpty(), "после переноса предупреждений нет: " + e.warnings());
        e.addFixture("Розетка");
        e.setPosition(2500, 275);
        ok(e.warnings().stream().anyMatch(s -> s.contains("Розетка")), "шкаф закрыл розетку: " + e.warnings());
        e.moveFixture(1, 4000, 15);
        ok(e.warnings().isEmpty(), "розетку перенесли");
        e.moveFixture(0, 100, 100);
        ok(e.warnings().stream().anyMatch(s -> s.contains("Колонна выходит")), "колонна вышла за стену");
        e.removeFixture(0);
        ok(e.project().fixtures().size() == 1, "колонна удалена");
        for (String k : Catalog.fixtureKinds()) ok(Catalog.fixture(k, 5000, 3500).box().insideRoom(5000, 3500), k + " влезает в комнату");

        Project p = e.project();
        ok(Project.fromJson(p.toJson()).equals(p), "сохранение с инженерными элементами");
        String old = "{\"version\":1,\"name\":\"Старый\",\"room\":{\"W\":5000,\"D\":3500,\"H\":2700,\"wallT\":100,\"openings\":[]},\"items\":[]}";
        ok(Project.fromJson(old).fixtures().isEmpty(), "старый файл без инженерных элементов открывается");
        ok(Drawing.plan(p).contains("class=\"fixture\""), "элемент на плане");
        System.out.println("OK, проверок: " + n);
    }
}
