package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Каталог готовых изделий. Всё собрано из деталей, поэтому правится, считается и чертится как любая мебель. */
public final class Catalog {
    private Catalog() {}
    public static List<String> names() { return List.of("Шкаф", "Комод", "Тумба", "Стеллаж", "Стол", "Стул", "Диван", "Кровать", "Панель", "Кресло", "Кухонный модуль", "Ванна", "Унитаз", "Тумба с раковиной", "Торшер"); }
    public static List<String> fixtureKinds() { return List.of("Колонна", "Радиатор", "Розетка", "Труба", "Светильник"); }
    /** Элемент у стены с y=0 (колонна — по центру комнаты). */
    public static Fixture fixture(String kind, double roomW, double roomD) {
        switch (kind) {
            case "Колонна": return new Fixture(kind, roomW / 2, roomD / 2, 400, 400, 0, 2700);
            case "Радиатор": return new Fixture(kind, roomW / 2, 50, 1000, 100, 100, 600);
            case "Розетка": return new Fixture(kind, roomW / 2, 15, 80, 30, 300, 80);
            case "Светильник": return new Fixture(kind, roomW / 2, roomD / 2, 300, 300, 2600, 100);
            case "Труба": return new Fixture(kind, 100, 100, 100, 100, 0, 2700);
            default: throw new IllegalArgumentException("Нет такого элемента: " + kind);
        }
    }
    public static List<String> categories() {
        return List.of("Кухни", "Шкафы", "Столы", "Стулья", "Диваны и кресла", "Кровати", "Комоды и тумбы", "Полки", "Сантехника", "Светильники", "Заготовки");
    }
    public static String category(String name) {
        switch (name) {
            case "Шкаф": return "Шкафы";
            case "Комод": case "Тумба": return "Комоды и тумбы";
            case "Стеллаж": return "Полки";
            case "Стол": return "Столы";
            case "Стул": return "Стулья";
            case "Диван": case "Кресло": return "Диваны и кресла";
            case "Кровать": return "Кровати";
            case "Кухонный модуль": return "Кухни";
            case "Ванна": case "Унитаз": case "Тумба с раковиной": return "Сантехника";
            case "Торшер": return "Светильники";
            default: return "Заготовки";
        }
    }
    /** Поиск по названию (без учёта регистра) и категории; category = null — любая. */
    public static List<String> search(String query, String category) {
        String q = query == null ? "" : query.trim().toLowerCase();
        List<String> r = new ArrayList<>();
        for (String n : names()) if ((category == null || category.equals(category(n))) && (q.isEmpty() || n.toLowerCase().contains(q))) r.add(n);
        return r;
    }
    static Part b(String n, double w, double d, double h, double x, double y, double z, String m) { return new Part(n, w, d, h, x, y, z, m); }

    public static Furniture create(String name) {
        switch (name) {
            case "Шкаф": return Core.cabinet(name, 1000, 550, 2100, 18, 3, "ЛДСП");
            case "Комод": return Core.cabinet(name, 1000, 500, 900, 18, 2, "ЛДСП");
            case "Тумба": return Core.cabinet(name, 450, 400, 500, 18, 1, "ЛДСП");
            case "Стеллаж": return Core.cabinet(name, 800, 300, 1800, 18, 4, "ЛДСП");
            case "Стол": {
                double w = 1600, d = 900, h = 750, l = 60;
                return new Furniture(name, 0, 0, 0, List.of(b("Столешница", w, d, 30, 0, 0, h - 30, "ЛДСП"),
                        b("Ножка", l, l, h - 30, 50, 50, 0, "Массив"), b("Ножка", l, l, h - 30, w - 50 - l, 50, 0, "Массив"),
                        b("Ножка", l, l, h - 30, 50, d - 50 - l, 0, "Массив"), b("Ножка", l, l, h - 30, w - 50 - l, d - 50 - l, 0, "Массив")));
            }
            case "Стул": {
                double w = 450;
                return new Furniture(name, 0, 0, 0, List.of(b("Сиденье", w, w, 40, 0, 0, 430, "Фанера"), b("Спинка", w, 30, 430, 0, 0, 470, "Фанера"),
                        b("Ножка", 40, 40, 430, 0, 0, 0, "Массив"), b("Ножка", 40, 40, 430, w - 40, 0, 0, "Массив"),
                        b("Ножка", 40, 40, 430, 0, w - 40, 0, "Массив"), b("Ножка", 40, 40, 430, w - 40, w - 40, 0, "Массив")));
            }
            case "Кресло":
                return new Furniture(name, 0, 0, 0, List.of(b("Основание", 850, 850, 300, 0, 0, 0, "Ткань"), b("Спинка", 850, 200, 500, 0, 650, 300, "Ткань"),
                        b("Подлокотник", 150, 650, 250, 0, 0, 300, "Ткань"), b("Подлокотник", 150, 650, 250, 700, 0, 300, "Ткань")));
            case "Кухонный модуль": return Core.cabinet(name, 600, 560, 850, 18, 1, "ЛДСП");
            case "Ванна": return new Furniture(name, 0, 0, 0, List.of(b("Корпус", 1700, 750, 560, 0, 0, 0, "Керамика")));
            case "Унитаз": return new Furniture(name, 0, 0, 0, List.of(b("Чаша", 380, 500, 400, 0, 0, 0, "Керамика"), b("Бачок", 380, 200, 400, 0, 0, 400, "Керамика")));
            case "Тумба с раковиной": return Editor.addPart(Core.cabinet(name, 600, 450, 800, 18, 1, "ЛДСП"), b("Раковина", 500, 400, 50, 50, 25, 800, "Керамика"));
            case "Торшер":
                return new Furniture(name, 0, 0, 0, List.of(b("Основание", 300, 300, 30, 50, 50, 0, "Металл"), b("Стойка", 40, 40, 1500, 180, 180, 30, "Металл"),
                        b("Абажур", 400, 400, 300, 0, 0, 1530, "Ткань")));
            case "Панель": return new Furniture(name, 0, 0, 0, List.of(b("Панель", 600, 400, 18, 0, 0, 0, "ЛДСП")));
            case "Диван": {
                double w = 2400, d = 900;
                return new Furniture(name, 0, 0, 0, List.of(b("Основание", w, d, 300, 0, 0, 0, "Ткань"), b("Спинка", w - 400, 200, 550, 200, d - 200, 300, "Ткань"),
                        b("Подлокотник", 200, d, 450, 0, 0, 300, "Ткань"), b("Подлокотник", 200, d, 450, w - 200, 0, 300, "Ткань")));
            }
            case "Кровать":
                return new Furniture(name, 0, 0, 0, List.of(b("Изголовье", 1600, 60, 900, 0, 0, 0, "ЛДСП"), b("Рама", 1600, 1940, 250, 0, 60, 0, "ЛДСП"),
                        b("Матрас", 1560, 1900, 200, 20, 80, 250, "Ткань")));
            default: throw new IllegalArgumentException("Нет такого изделия: " + name);
        }
    }
}
