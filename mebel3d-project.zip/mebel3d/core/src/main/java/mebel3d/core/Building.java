package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Квартира или дом: несколько помещений с положением на общем плане (мм). */
public record Building(String name, List<Placed> rooms) {
    public Building { rooms = List.copyOf(rooms); }

    public record Placed(Project project, double ox, double oy) {
        Box footprint() { Room r = project.room(); return new Box(ox + r.W() / 2, oy + r.D() / 2, r.W(), r.D(), 0, 0, 1); }
    }

    public Building add(Project p, double ox, double oy) { List<Placed> l = new ArrayList<>(rooms); l.add(new Placed(p, ox, oy)); return new Building(name, l); }

    public Building withName(String n) { return new Building(n, rooms); }
    public Building replace(int i, Project p) { List<Placed> l = new ArrayList<>(rooms); Placed o = l.get(i); l.set(i, new Placed(p, o.ox, o.oy)); return new Building(name, l); }
    public Building remove(int i) { List<Placed> l = new ArrayList<>(rooms); l.remove(i); return new Building(name, l); }
    public Building move(int i, double ox, double oy) { List<Placed> l = new ArrayList<>(rooms); l.set(i, new Placed(l.get(i).project(), ox, oy)); return new Building(name, l); }

    /** Свободное место для нового помещения: справа от последнего; зазор — толщина общей стены (большая из двух), при нехватке места — новая строка. */
    public double[] nextFreeOrigin(double newW, double newD, double wallT) {
        if (rooms.isEmpty()) return new double[]{0, 0};
        double right = -Double.MAX_VALUE, bottom = -Double.MAX_VALUE, top = Double.MAX_VALUE;
        for (Placed r : rooms) { right = Math.max(right, r.ox + r.project().room().W()); bottom = Math.max(bottom, r.oy + r.project().room().D()); top = Math.min(top, r.oy); }
        double gap = Math.max(wallT, rooms.get(rooms.size() - 1).project().room().wallT()); // одна общая стена
        return right + gap + newW <= 16000 ? new double[]{right + gap, top} : new double[]{0, bottom + gap};
    }

    private static List<double[]> doors(Placed r, int wall, boolean alongY) {
        List<double[]> l = new ArrayList<>();
        for (Opening o : r.project().room().openings())
            if (o.wall() == wall && o.sill() == 0) l.add(new double[]{(alongY ? r.oy : r.ox) + o.offset(), (alongY ? r.oy : r.ox) + o.offset() + o.width()});
        return l;
    }
    private static boolean overlap(List<double[]> a, List<double[]> b) {
        for (double[] x : a) for (double[] y : b) if (Math.min(x[1], y[1]) - Math.max(x[0], y[0]) >= 600) return true;
        return false;
    }
    /** Проходы между соседними помещениями: двери от пола в общей стене, перекрывающиеся не меньше чем на 600 мм. */
    public List<String> passages() {
        Set<String> r = new LinkedHashSet<>();
        for (int i = 0; i < rooms.size(); i++)
            for (int j = i + 1; j < rooms.size(); j++) {
                Placed a = rooms.get(i), c = rooms.get(j);
                Room ra = a.project().room(), rc = c.project().room();
                double tol = ra.wallT() + rc.wallT();
                boolean ok = (Math.abs(a.ox + ra.W() - c.ox) <= tol && overlap(doors(a, 1, true), doors(c, 3, true)))
                        || (Math.abs(c.ox + rc.W() - a.ox) <= tol && overlap(doors(a, 3, true), doors(c, 1, true)))
                        || (Math.abs(a.oy + ra.D() - c.oy) <= tol && overlap(doors(a, 2, false), doors(c, 0, false)))
                        || (Math.abs(c.oy + rc.D() - a.oy) <= tol && overlap(doors(a, 0, false), doors(c, 2, false)));
                if (ok) r.add(a.project().name() + " ⇄ " + c.project().name());
            }
        return new ArrayList<>(r);
    }

    public double totalAreaM2() { return rooms.stream().mapToDouble(r -> r.project().room().W() * r.project().room().D() / 1e6).sum(); }

    public List<String> warnings() {
        List<String> w = new ArrayList<>();
        for (int i = 0; i < rooms.size(); i++) {
            for (int j = i + 1; j < rooms.size(); j++)
                if (rooms.get(i).footprint().overlaps(rooms.get(j).footprint()))
                    w.add("Помещения «" + rooms.get(i).project().name() + "» и «" + rooms.get(j).project().name() + "» пересекаются");
            for (String s : rooms.get(i).project().warnings()) w.add(rooms.get(i).project().name() + ": " + s);
        }
        return w;
    }

    /** Пары помещений, разделённых одной стеной: зазор не больше суммы толщин стен и есть общий участок. */
    public List<String> neighbors() {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < rooms.size(); i++)
            for (int j = i + 1; j < rooms.size(); j++) {
                Placed a = rooms.get(i), b = rooms.get(j);
                double tol = a.project().room().wallT() + b.project().room().wallT();
                double aw = a.project().room().W(), ad = a.project().room().D(), bw = b.project().room().W(), bd = b.project().room().D();
                double gx = Math.max(b.ox - (a.ox + aw), a.ox - (b.ox + bw)), gy = Math.max(b.oy - (a.oy + ad), a.oy - (b.oy + bd));
                double shareY = Math.min(a.oy + ad, b.oy + bd) - Math.max(a.oy, b.oy), shareX = Math.min(a.ox + aw, b.ox + bw) - Math.max(a.ox, b.ox);
                if ((gx >= 0 && gx <= tol && shareY > 0 && gy < 0) || (gy >= 0 && gy <= tol && shareX > 0 && gx < 0))
                    r.add(a.project().name() + " — " + b.project().name());
            }
        return r;
    }

    public String toJson() {
        StringBuilder b = new StringBuilder("{\"version\":1,\"name\":" + Project.q(name) + ",\"rooms\":[");
        for (int i = 0; i < rooms.size(); i++)
            b.append(i > 0 ? "," : "").append("{\"ox\":").append(Project.n(rooms.get(i).ox)).append(",\"oy\":").append(Project.n(rooms.get(i).oy))
             .append(",\"project\":").append(rooms.get(i).project().toJson()).append("}");
        return b.append("]}").toString();
    }

    @SuppressWarnings("unchecked")
    public static Building fromJson(String json) {
        try {
            Map<String, Object> m = (Map<String, Object>) new Project.Json(json).val();
            List<Placed> l = new ArrayList<>();
            for (Object o : (List<Object>) m.get("rooms")) {
                Map<String, Object> e = (Map<String, Object>) o;
                l.add(new Placed(Project.fromMap((Map<String, Object>) e.get("project")), (Double) e.get("ox"), (Double) e.get("oy")));
            }
            return new Building((String) m.get("name"), l);
        } catch (IllegalArgumentException e) { throw e;
        } catch (RuntimeException e) { throw new IllegalArgumentException("Файл проекта повреждён", e); }
    }
}
