package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Материалы и цвета. Цвет хранится в справочнике, у детали — только название материала. */
public final class Materials {
    private Materials() {}
    private static final Map<String, Integer> C = new LinkedHashMap<>();
    static {
        C.put("ЛДСП", 0xD2B48C); C.put("ЛДСП белый", 0xE9E5DF); C.put("ЛДСП дуб", 0xC9A36B); C.put("ЛДСП орех", 0x7A5638); C.put("ЛДСП графит", 0x4A4F57);
        C.put("Массив", 0xB98F5B); C.put("Массив дуб", 0xC49A62); C.put("Фанера", 0xD8BE8C); C.put("ХДФ", 0xBFB6A6);
        C.put("Ткань", 0xCDBFAE); C.put("Ткань бежевый", 0xCDBFAE); C.put("Ткань зелёный", 0x9DB08F); C.put("Ткань серый", 0x9AA0A6);
        C.put("Керамика", 0xF2F2F2); C.put("Металл", 0xB0B5BB);
    }
    public static List<String> names() { return List.copyOf(C.keySet()); }
    /** Цвет 0xRRGGBB; для неизвестного материала нейтральный серый. */
    public static int color(String m) { return C.getOrDefault(m, 0xCCCCCC); }

    /** Вид поверхности для отрисовки: «дерево», «ткань» или «гладкая». */
    public static String texture(String m) {
        if (m.startsWith("Массив") || m.equals("ЛДСП дуб") || m.equals("ЛДСП орех") || m.equals("Фанера")) return "дерево";
        if (m.startsWith("Ткань")) return "ткань";
        return "гладкая";
    }

    /** Основной материал изделия — тот, у которого больше суммарная площадь деталей. */
    public static String dominant(Furniture f) {
        String best = null; double max = -1;
        for (Map.Entry<String, Double> e : Core.materialAreaM2(f).entrySet()) if (e.getValue() > max) { max = e.getValue(); best = e.getKey(); }
        return best;
    }

    /** Заменяет основной материал; задняя стенка из ХДФ и прочие второстепенные материалы не меняются. */
    public static Furniture replaceMain(Furniture f, String mat) {
        if (!C.containsKey(mat)) throw new IllegalArgumentException("Неизвестный материал: " + mat);
        String d = dominant(f);
        List<Part> out = new ArrayList<>();
        for (Part p : f.parts()) out.add(p.material().equals(d) ? new Part(p.name(), p.w(), p.d(), p.h(), p.x(), p.y(), p.z(), mat) : p);
        return new Furniture(f.name(), f.x(), f.y(), f.rot(), out);
    }
}
