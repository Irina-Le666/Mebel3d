package mebel3d.core;

import mebel3d.core.Core.*;
import mebel3d.core.Photos.*;
import java.util.*;

/** Проект: комната и мебель. Неизменяемый — каждая правка даёт новую версию (основа отмены/повтора). */
public record Project(String name, Room room, List<Furniture> items, List<Fixture> fixtures, List<Photo> photos, List<Group> groups) {
    /** Группа изделий: двигается и поворачивается как одно целое. Индексы — позиции в items. */
    public record Group(String name, List<Integer> items) { public Group { items = List.copyOf(items); } }

    public Project { items = List.copyOf(items); fixtures = List.copyOf(fixtures); photos = List.copyOf(photos); groups = List.copyOf(groups); }
    public Project(String name, Room room, List<Furniture> items) { this(name, room, items, List.of(), List.of(), List.of()); }
    public Project(String name, Room room, List<Furniture> items, List<Fixture> fixtures) { this(name, room, items, fixtures, List.of(), List.of()); }
    public Project(String name, Room room, List<Furniture> items, List<Fixture> fixtures, List<Photo> photos) { this(name, room, items, fixtures, photos, List.of()); }

    public Project withName(String n) { return new Project(n, room, items, fixtures, photos, groups); }
    public Project withRoom(Room r) { return new Project(name, r, items, fixtures, photos, groups); }
    public Project addFixture(Fixture f) { List<Fixture> l = new ArrayList<>(fixtures); l.add(f); return new Project(name, room, items, l, photos, groups); }
    public Project replaceFixture(int i, Fixture f) { List<Fixture> l = new ArrayList<>(fixtures); l.set(i, f); return new Project(name, room, items, l, photos, groups); }
    public Project removeFixture(int i) { List<Fixture> l = new ArrayList<>(fixtures); l.remove(i); return new Project(name, room, items, l, photos, groups); }
    public Project addPhoto(Photo f) { List<Photo> l = new ArrayList<>(photos); l.add(f); return new Project(name, room, items, fixtures, l, groups); }
    public Project replacePhoto(int i, Photo f) { List<Photo> l = new ArrayList<>(photos); l.set(i, f); return new Project(name, room, items, fixtures, l, groups); }
    public Project removePhoto(int i) { List<Photo> l = new ArrayList<>(photos); l.remove(i); return new Project(name, room, items, fixtures, l, groups); }
    public Project add(Furniture f) { List<Furniture> l = new ArrayList<>(items); l.add(f); return new Project(name, room, l, fixtures, photos, groups); }
    public Project replace(int i, Furniture f) { List<Furniture> l = new ArrayList<>(items); l.set(i, f); return new Project(name, room, l, fixtures, photos, groups); }
    /** Удаляет изделие; индексы в группах пересчитываются, группа из одного изделия распадается. */
    public Project remove(int i) {
        List<Furniture> l = new ArrayList<>(items); l.remove(i);
        List<Group> g = new ArrayList<>();
        for (Group x : groups) {
            List<Integer> m = new ArrayList<>();
            for (int k : x.items()) if (k != i) m.add(k > i ? k - 1 : k);
            if (m.size() >= 2) g.add(new Group(x.name(), m));
        }
        return new Project(name, room, l, fixtures, photos, g);
    }
    /** Объединяет изделия в группу. Изделие может быть только в одной группе: из старых групп оно уходит. */
    public Project group(String gname, List<Integer> idx) {
        Set<Integer> s = new TreeSet<>(idx);
        if (s.size() < 2) throw new IllegalArgumentException("В группе должно быть не меньше двух изделий");
        for (int k : s) if (k < 0 || k >= items.size()) throw new IllegalArgumentException("Нет такого изделия");
        List<Group> g = new ArrayList<>();
        for (Group x : groups) { List<Integer> m = new ArrayList<>(x.items()); m.removeAll(s); if (m.size() >= 2) g.add(new Group(x.name(), m)); }
        g.add(new Group(gname, new ArrayList<>(s)));
        return new Project(name, room, items, fixtures, photos, g);
    }
    public Project ungroup(int item) {
        List<Group> g = new ArrayList<>();
        for (Group x : groups) if (!x.items().contains(item)) g.add(x);
        return new Project(name, room, items, fixtures, photos, g);
    }
    public int groupOf(int item) { for (int k = 0; k < groups.size(); k++) if (groups.get(k).items().contains(item)) return k; return -1; }
    public List<Integer> membersOf(int item) { int g = groupOf(item); return g < 0 ? List.of(item) : groups.get(g).items(); }

    /** Изделия, которые выходят за стены, пересекаются друг с другом или с инженерными элементами. */
    public Set<Integer> collidingItems() {
        Set<Integer> r = new TreeSet<>();
        for (int i = 0; i < items.size(); i++) {
            Furniture f = items.get(i);
            if (!f.box().insideRoom(room.W(), room.D())) r.add(i);
            for (Fixture x : fixtures) if (f.box().overlaps(x.box())) r.add(i);
            for (int j = i + 1; j < items.size(); j++) if (f.box().overlaps(items.get(j).box())) { r.add(i); r.add(j); }
        }
        return r;
    }

    /** Предупреждения: выход за стены и столкновения изделий. */
    public List<String> warnings() {
        List<String> w = new ArrayList<>(room.validate());
        for (Furniture f : items) if (!f.box().insideRoom(room.W(), room.D())) w.add(f.name() + " выходит за стены");
        for (Fixture x : fixtures) {
            if (!x.box().insideRoom(room.W(), room.D())) w.add(x.kind() + " выходит за стены");
            for (Furniture f : items) if (f.box().overlaps(x.box())) w.add(f.name() + " мешает: " + x.kind());
        }
        for (int i = 0; i < items.size(); i++)
            for (int j = i + 1; j < items.size(); j++)
                if (items.get(i).box().overlaps(items.get(j).box())) w.add(items.get(i).name() + " пересекается с " + items.get(j).name());
        return w;
    }

    /** История правок. */
    public static final class History {
        private final Deque<Project> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
        private Project cur;
        public History(Project p) { cur = p; }
        public Project current() { return cur; }
        public void apply(Project p) { undo.push(cur); if (undo.size() > 100) undo.removeLast(); redo.clear(); cur = p; }
        public boolean undo() { if (undo.isEmpty()) return false; redo.push(cur); cur = undo.pop(); return true; }
        public boolean redo() { if (redo.isEmpty()) return false; undo.push(cur); cur = redo.pop(); return true; }
    }

    // ---------- сохранение ----------
    static String n(double d) { return d == Math.rint(d) ? Long.toString((long) d) : Double.toString(d); }
    static String q(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }

    public String toJson() {
        StringBuilder b = new StringBuilder("{\"version\":1,\"name\":" + q(name) + ",\"room\":{\"W\":" + n(room.W()) + ",\"D\":" + n(room.D())
                + ",\"H\":" + n(room.H()) + ",\"wallT\":" + n(room.wallT()) + ",\"openings\":[");
        for (int i = 0; i < room.openings().size(); i++) {
            Opening o = room.openings().get(i);
            b.append(i > 0 ? "," : "").append("{\"wall\":").append(o.wall()).append(",\"offset\":").append(n(o.offset())).append(",\"width\":")
             .append(n(o.width())).append(",\"height\":").append(n(o.height())).append(",\"sill\":").append(n(o.sill())).append("}");
        }
        b.append("]},\"items\":[");
        for (int i = 0; i < items.size(); i++) {
            Furniture f = items.get(i);
            b.append(i > 0 ? "," : "").append("{\"name\":").append(q(f.name())).append(",\"x\":").append(n(f.x())).append(",\"y\":").append(n(f.y()))
             .append(",\"rot\":").append(n(f.rot())).append(",\"parts\":[");
            for (int j = 0; j < f.parts().size(); j++) {
                Part p = f.parts().get(j);
                b.append(j > 0 ? "," : "").append("{\"name\":").append(q(p.name())).append(",\"w\":").append(n(p.w())).append(",\"d\":").append(n(p.d()))
                 .append(",\"h\":").append(n(p.h())).append(",\"x\":").append(n(p.x())).append(",\"y\":").append(n(p.y())).append(",\"z\":").append(n(p.z()))
                 .append(",\"material\":").append(q(p.material())).append("}");
            }
            b.append("]}");
        }
        b.append("],\"fixtures\":[");
        for (int i = 0; i < fixtures.size(); i++) {
            Fixture x = fixtures.get(i);
            b.append(i > 0 ? "," : "").append("{\"kind\":").append(q(x.kind())).append(",\"x\":").append(n(x.x())).append(",\"y\":").append(n(x.y()))
             .append(",\"w\":").append(n(x.w())).append(",\"d\":").append(n(x.d())).append(",\"z\":").append(n(x.z())).append(",\"h\":").append(n(x.h())).append("}");
        }
        b.append("],\"photos\":[");
        for (int i = 0; i < photos.size(); i++) {
            Photo h = photos.get(i);
            b.append(i > 0 ? "," : "").append("{\"name\":").append(q(h.name())).append(",\"uri\":").append(q(h.uri())).append(",\"wall\":").append(h.wall())
             .append(",\"calAx\":").append(n(h.calAx())).append(",\"calAy\":").append(n(h.calAy())).append(",\"calBx\":").append(n(h.calBx())).append(",\"calBy\":").append(n(h.calBy()))
             .append(",\"knownMm\":").append(n(h.knownMm())).append(",\"originX\":").append(n(h.originX())).append(",\"floorY\":").append(n(h.floorY())).append(",\"marks\":[");
            for (int j = 0; j < h.marks().size(); j++) {
                Mark m = h.marks().get(j);
                b.append(j > 0 ? "," : "").append("{\"kind\":").append(q(m.kind())).append(",\"x1\":").append(n(m.x1())).append(",\"y1\":").append(n(m.y1()))
                 .append(",\"x2\":").append(n(m.x2())).append(",\"y2\":").append(n(m.y2())).append("}");
            }
            b.append("]}");
        }
        b.append("],\"groups\":[");
        for (int i = 0; i < groups.size(); i++) {
            Group g = groups.get(i);
            b.append(i > 0 ? "," : "").append("{\"name\":").append(q(g.name())).append(",\"items\":[");
            for (int j = 0; j < g.items().size(); j++) b.append(j > 0 ? "," : "").append(g.items().get(j));
            b.append("]}");
        }
        return b.append("]}").toString();
    }

    @SuppressWarnings("unchecked")
    public static Project fromJson(String json) {
        try { return fromMap((Map<String, Object>) new Json(json).val());
        } catch (IllegalArgumentException e) { throw e;
        } catch (RuntimeException e) { throw new IllegalArgumentException("Файл проекта повреждён", e); }
    }

    @SuppressWarnings("unchecked")
    static Project fromMap(Map<String, Object> m) {
        {
            if (((Double) m.get("version")).intValue() != 1) throw new IllegalArgumentException("Неизвестная версия проекта");
            Map<String, Object> r = (Map<String, Object>) m.get("room");
            List<Opening> ops = new ArrayList<>();
            for (Object o : (List<Object>) r.get("openings")) {
                Map<String, Object> e = (Map<String, Object>) o;
                ops.add(new Opening(d(e, "wall") == 0 ? 0 : (int) d(e, "wall"), d(e, "offset"), d(e, "width"), d(e, "height"), d(e, "sill")));
            }
            Room room = new Room(d(r, "W"), d(r, "D"), d(r, "H"), d(r, "wallT"), ops);
            List<Furniture> fs = new ArrayList<>();
            for (Object o : (List<Object>) m.get("items")) {
                Map<String, Object> e = (Map<String, Object>) o;
                List<Part> ps = new ArrayList<>();
                for (Object po : (List<Object>) e.get("parts")) {
                    Map<String, Object> p = (Map<String, Object>) po;
                    ps.add(new Part((String) p.get("name"), d(p, "w"), d(p, "d"), d(p, "h"), d(p, "x"), d(p, "y"), d(p, "z"), (String) p.get("material")));
                }
                fs.add(new Furniture((String) e.get("name"), d(e, "x"), d(e, "y"), d(e, "rot"), ps));
            }
            List<Fixture> xs = new ArrayList<>();
            Object fo = m.get("fixtures");
            if (fo != null) for (Object o : (List<Object>) fo) {
                Map<String, Object> e = (Map<String, Object>) o;
                xs.add(new Fixture((String) e.get("kind"), d(e, "x"), d(e, "y"), d(e, "w"), d(e, "d"), d(e, "z"), d(e, "h")));
            }
            List<Photo> hs = new ArrayList<>();
            Object po = m.get("photos");
            if (po != null) for (Object o : (List<Object>) po) {
                Map<String, Object> e = (Map<String, Object>) o;
                List<Mark> ms = new ArrayList<>();
                for (Object mo : (List<Object>) e.get("marks")) {
                    Map<String, Object> k = (Map<String, Object>) mo;
                    ms.add(new Mark((String) k.get("kind"), d(k, "x1"), d(k, "y1"), d(k, "x2"), d(k, "y2")));
                }
                hs.add(new Photo((String) e.get("name"), (String) e.get("uri"), (int) d(e, "wall"), d(e, "calAx"), d(e, "calAy"), d(e, "calBx"), d(e, "calBy"),
                        d(e, "knownMm"), d(e, "originX"), d(e, "floorY"), ms));
            }
            List<Group> gs = new ArrayList<>();
            Object go = m.get("groups");
            if (go != null) for (Object o : (List<Object>) go) {
                Map<String, Object> e = (Map<String, Object>) o;
                List<Integer> idx = new ArrayList<>();
                for (Object v : (List<Object>) e.get("items")) idx.add(((Double) v).intValue());
                gs.add(new Group((String) e.get("name"), idx));
            }
            return new Project((String) m.get("name"), room, fs, xs, hs, gs);
        }
    }
    private static double d(Map<String, Object> m, String k) { return (Double) m.get(k); }

    /** Минимальный разбор JSON. */
    static final class Json {
        final String s; int i;
        Json(String s) { this.s = s; }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        Object val() {
            ws(); char c = s.charAt(i);
            if (c == '{') { i++; Map<String, Object> m = new LinkedHashMap<>(); ws(); if (s.charAt(i) == '}') { i++; return m; }
                while (true) { ws(); String k = str(); ws(); i++; m.put(k, val()); ws(); if (s.charAt(i++) == '}') return m; } }
            if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (s.charAt(i) == ']') { i++; return l; }
                while (true) { l.add(val()); ws(); if (s.charAt(i++) == ']') return l; } }
            if (c == '"') return str();
            int st = i; while (i < s.length() && "+-.eE0123456789".indexOf(s.charAt(i)) >= 0) i++;
            return Double.parseDouble(s.substring(st, i));
        }
        String str() {
            i++; StringBuilder b = new StringBuilder();
            while (s.charAt(i) != '"') { char c = s.charAt(i++); if (c == '\\') b.append(s.charAt(i++)); else b.append(c); }
            i++; return b.toString();
        }
    }
}
