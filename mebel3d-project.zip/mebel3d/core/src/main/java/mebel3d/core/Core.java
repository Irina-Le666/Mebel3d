package mebel3d.core;

import java.util.*;

/** Геометрическое ядро «Мебель 3D». Единицы: миллиметры. Без зависимостей от Android. */
public final class Core {
    private Core() {}
    static final double EPS = 1e-6;

    /** Ориентированный параллелепипед: основание повёрнуто вокруг центра, вертикаль по Z. */
    public record Box(double cx, double cy, double w, double d, double rotDeg, double z0, double h) {
        public double[][] corners() {
            double a = Math.toRadians(rotDeg), c = Math.cos(a), s = Math.sin(a);
            double[][] k = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            double[][] r = new double[4][2];
            for (int i = 0; i < 4; i++) {
                double px = k[i][0] * w / 2, py = k[i][1] * d / 2;
                r[i][0] = cx + px * c - py * s;
                r[i][1] = cy + px * s + py * c;
            }
            return r;
        }
        public boolean insideRoom(double W, double D) {
            for (double[] p : corners())
                if (p[0] < -EPS || p[1] < -EPS || p[0] > W + EPS || p[1] > D + EPS) return false;
            return true;
        }
        /** Пересечение по объёму; касание граней пересечением не считается. */
        public boolean overlaps(Box o) {
            if (z0 >= o.z0 + o.h - EPS || o.z0 >= z0 + h - EPS) return false;
            double[][] A = corners(), B = o.corners();
            for (double[][] P : new double[][][]{A, B})
                for (int i = 0; i < 2; i++) {
                    double ax = P[i + 1][0] - P[i][0], ay = P[i + 1][1] - P[i][1];
                    double[] ra = range(A, ax, ay), rb = range(B, ax, ay);
                    if (ra[1] <= rb[0] + EPS || rb[1] <= ra[0] + EPS) return false;
                }
            return true;
        }
        private static double[] range(double[][] P, double ax, double ay) {
            double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (double[] p : P) { double v = p[0] * ax + p[1] * ay; lo = Math.min(lo, v); hi = Math.max(hi, v); }
            double n = Math.hypot(ax, ay);
            return new double[]{lo / n, hi / n};
        }
    }

    /** Деталь мебели. Координаты (x,y,z) — угол детали в системе изделия, w вдоль X, d вдоль Y, h вдоль Z. */
    public record Part(String name, double w, double d, double h, double x, double y, double z, String material) {
        public Part { if (w <= 0 || d <= 0 || h <= 0) throw new IllegalArgumentException("Размеры детали должны быть > 0: " + name); }
        Box local() { return new Box(x + w / 2, y + d / 2, w, d, 0, z, h); }
        /** Площадь большей грани — для расчёта листового материала, м². */
        public double areaM2() {
            double[] a = {w, d, h}; Arrays.sort(a);
            return a[1] * a[2] / 1e6;
        }
    }

    /** Мебельное изделие. (x,y) — центр основания в комнате, rot — поворот, градусы. */
    public record Furniture(String name, double x, double y, double rot, List<Part> parts) {
        public Furniture { parts = List.copyOf(parts); }
        public double width()  { return parts.stream().mapToDouble(p -> p.x + p.w).max().orElse(0); }
        public double depth()  { return parts.stream().mapToDouble(p -> p.y + p.d).max().orElse(0); }
        public double height() { return parts.stream().mapToDouble(p -> p.z + p.h).max().orElse(0); }
        public Box box() { return new Box(x, y, width(), depth(), rot, 0, height()); }
        public Furniture moved(double nx, double ny) { return new Furniture(name, nx, ny, rot, parts); }
        public Furniture rotated(double r) { return new Furniture(name, x, y, r, parts); }
        /** Все детали не должны пересекаться друг с другом. */
        public List<String> selfIntersections() {
            List<String> r = new ArrayList<>();
            for (int i = 0; i < parts.size(); i++)
                for (int j = i + 1; j < parts.size(); j++)
                    if (parts.get(i).local().overlaps(parts.get(j).local()))
                        r.add(parts.get(i).name + " × " + parts.get(j).name);
            return r;
        }
    }

    /** Параметрический шкаф: изменение любого размера пересчитывает все связанные детали. */
    public static Furniture cabinet(String name, double W, double D, double H, double t, int shelves, String mat) {
        final double back = 4;
        if (shelves < 0 || 2 * t >= W || 2 * t >= H || back >= D) throw new IllegalArgumentException("Недопустимые размеры шкафа");
        List<Part> p = new ArrayList<>();
        p.add(new Part("Боковина левая", t, D, H, 0, 0, 0, mat));
        p.add(new Part("Боковина правая", t, D, H, W - t, 0, 0, mat));
        p.add(new Part("Низ", W - 2 * t, D - back, t, t, 0, 0, mat));
        p.add(new Part("Верх", W - 2 * t, D - back, t, t, 0, H - t, mat));
        p.add(new Part("Задняя стенка", W - 2 * t, back, H - 2 * t, t, D - back, t, "ХДФ"));
        double gap = (H - 2 * t - shelves * t) / (shelves + 1);
        if (shelves > 0 && gap < 10) throw new IllegalArgumentException("Слишком много полок");
        for (int i = 0; i < shelves; i++)
            p.add(new Part("Полка", W - 2 * t, D - back, t, t, 0, t + gap * (i + 1) + t * i, mat));
        return new Furniture(name, W / 2, D / 2, 0, p);
    }

    public record BomLine(String name, double a, double b, double c, String material, int qty) {}

    /** Спецификация: одинаковые детали группируются. */
    public static List<BomLine> bom(Furniture f) {
        Map<String, BomLine> m = new LinkedHashMap<>();
        for (Part p : f.parts) {
            String key = p.name.replace(" левая", "").replace(" правая", "") + "|" + p.w + "|" + p.d + "|" + p.h + "|" + p.material;
            m.merge(key, new BomLine(p.name.replace(" левая", "").replace(" правая", ""), p.w, p.d, p.h, p.material, 1),
                    (o, n) -> new BomLine(o.name, o.a, o.b, o.c, o.material, o.qty + 1));
        }
        return new ArrayList<>(m.values());
    }

    public static Map<String, Double> materialAreaM2(Furniture f) {
        Map<String, Double> r = new TreeMap<>();
        for (Part p : f.parts) r.merge(p.material, p.areaM2(), Double::sum);
        return r;
    }

    /** Инженерный элемент или препятствие: колонна, радиатор, розетка, труба. Габарит по полу плюс отметка и высота. */
    public record Fixture(String kind, double x, double y, double w, double d, double z, double h) {
        public Fixture { if (w <= 0 || d <= 0 || h <= 0) throw new IllegalArgumentException("Размеры элемента должны быть > 0"); }
        public Box box() { return new Box(x, y, w, d, 0, z, h); }
    }

    /** Проём в стене. Стены: 0 — y=0 (длина W), 1 — x=W (длина D), 2 — y=D (W), 3 — x=0 (D). */
    public record Opening(int wall, double offset, double width, double height, double sill) {}

    public record Room(double W, double D, double H, double wallT, List<Opening> openings) {
        public List<String> validate() {
            List<String> e = new ArrayList<>();
            for (Opening o : openings) {
                double len = o.wall % 2 == 0 ? W : D;
                if (o.wall < 0 || o.wall > 3) e.add("Нет стены " + o.wall);
                else if (o.offset < 0 || o.offset + o.width > len + EPS) e.add("Проём выходит за стену " + o.wall);
                else if (o.sill < 0 || o.sill + o.height > H + EPS) e.add("Проём выше стены " + o.wall);
            }
            for (int i = 0; i < openings.size(); i++)
                for (int j = i + 1; j < openings.size(); j++) {
                    Opening a = openings.get(i), b = openings.get(j);
                    if (a.wall == b.wall && a.offset < b.offset + b.width - EPS && b.offset < a.offset + a.width - EPS)
                        e.add("Проёмы пересекаются на стене " + a.wall);
                }
            return e;
        }
    }
}
