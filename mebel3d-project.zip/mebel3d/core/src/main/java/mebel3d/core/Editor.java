package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Правка деталей и групп. Связь между деталями определяется касанием граней (в том числе по ребру). */
public final class Editor {
    private Editor() {}
    static final double E = 1e-6;

    static double p(Part q, int a) { return a == 0 ? q.x() : a == 1 ? q.y() : q.z(); }
    static double s(Part q, int a) { return a == 0 ? q.w() : a == 1 ? q.d() : q.h(); }

    /** j примыкает к i по оси a с положительной стороны: min-грань j совпадает с max-гранью i, в остальных осях детали пересекаются или касаются. */
    static boolean adj(double[][] P, double[][] S, int i, int j, int a) {
        if (Math.abs(P[j][a] - (P[i][a] + S[i][a])) > E) return false;
        boolean positive = false;
        for (int b = 0; b < 3; b++) {
            if (b == a) continue;
            double ov = Math.min(P[i][b] + S[i][b], P[j][b] + S[j][b]) - Math.max(P[i][b], P[j][b]);
            if (ov < -E) return false;
            if (ov > E) positive = true;
        }
        return positive;
    }

    /**
     * Меняет размер детали вдоль оси (0 — X, 1 — Y, 2 — Z). Закрепляется min-грань (anchorMax=false) или max-грань.
     * Детали, приклеенные к подвижной грани, сдвигаются; если деталь зажата между подвижной гранью и другой деталью — растягивается.
     */
    public static Furniture resizePart(Furniture f, int idx, int a, double newSize, boolean anchorMax) {
        if (newSize <= 0) throw new IllegalArgumentException("Размер должен быть больше нуля");
        List<Part> ps = f.parts(); int n = ps.size();
        double[][] P0 = new double[n][3], S0 = new double[n][3], P = new double[n][3], S = new double[n][3];
        for (int i = 0; i < n; i++) for (int b = 0; b < 3; b++) { P0[i][b] = P[i][b] = p(ps.get(i), b); S0[i][b] = S[i][b] = s(ps.get(i), b); }
        double d = newSize - S0[idx][a];
        if (Math.abs(d) < E) return f;
        int sg = anchorMax ? -1 : 1;
        S[idx][a] = newSize;
        if (anchorMax) P[idx][a] = P0[idx][a] - d;
        boolean[] seen = new boolean[n]; seen[idx] = true;
        Deque<Integer> q = new ArrayDeque<>(); q.add(idx);
        while (!q.isEmpty()) {
            int m = q.poll();
            for (int j = 0; j < n; j++) {
                if (seen[j]) continue;
                if (!(sg > 0 ? adj(P0, S0, m, j, a) : adj(P0, S0, j, m, a))) continue;
                seen[j] = true;
                boolean span = false;
                for (int k = 0; k < n && !span; k++)
                    if (k != j && k != m && (sg > 0 ? adj(P0, S0, j, k, a) : adj(P0, S0, k, j, a))) span = true;
                if (span) { if (sg > 0) P[j][a] += d; S[j][a] -= d; }
                else { P[j][a] += sg * d; q.add(j); }
            }
        }
        List<Part> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (S[i][0] <= E || S[i][1] <= E || S[i][2] <= E) throw new IllegalArgumentException("Деталь «" + ps.get(i).name() + "» становится слишком маленькой");
            Part o = ps.get(i);
            out.add(new Part(o.name(), S[i][0], S[i][1], S[i][2], P[i][0], P[i][1], P[i][2], o.material()));
        }
        return new Furniture(f.name(), f.x(), f.y(), f.rot(), out);
    }

    /** Сдвиг группы предметов. */
    public static Project moveItems(Project pr, List<Integer> idx, double dx, double dy) {
        Project r = pr;
        for (int i : idx) { Furniture f = pr.items().get(i); r = r.replace(i, f.moved(f.x() + dx, f.y() + dy)); }
        return r;
    }

    /** Поворот группы вокруг её центра. Предметы сохраняют взаимное расположение. */
    public static Project rotateItems(Project pr, List<Integer> idx, double deg) {
        if (idx.isEmpty()) return pr;
        double cx = 0, cy = 0;
        for (int i : idx) { cx += pr.items().get(i).x(); cy += pr.items().get(i).y(); }
        cx /= idx.size(); cy /= idx.size();
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        Project r = pr;
        for (int i : idx) {
            Furniture f = pr.items().get(i);
            double dx = f.x() - cx, dy = f.y() - cy;
            r = r.replace(i, new Furniture(f.name(), cx + dx * c - dy * s, cy + dx * s + dy * c, f.rot() + deg, f.parts()));
        }
        return r;
    }

    /** Общие размеры изделия. Шкафы пересобираются с сохранением толщины, полок и материала; прочие изделия масштабируются по осям. */
    public static Furniture setOverallSize(Furniture f, double W, double D, double H) {
        if (W <= 0 || D <= 0 || H <= 0) throw new IllegalArgumentException("Размеры должны быть больше нуля");
        Part left = f.parts().stream().filter(q -> q.name().equals("Боковина левая")).findFirst().orElse(null);
        if (left != null) {
            int sh = (int) f.parts().stream().filter(q -> q.name().equals("Полка")).count();
            return new Furniture(f.name(), f.x(), f.y(), f.rot(), Core.cabinet(f.name(), W, D, H, left.w(), sh, left.material()).parts());
        }
        double kx = W / f.width(), ky = D / f.depth(), kz = H / f.height();
        List<Part> out = new ArrayList<>();
        for (Part q : f.parts()) out.add(new Part(q.name(), q.w() * kx, q.d() * ky, q.h() * kz, q.x() * kx, q.y() * ky, q.z() * kz, q.material()));
        return new Furniture(f.name(), f.x(), f.y(), f.rot(), out);
    }

    // ---------- конструктор: правка набора деталей ----------

    /** Пересобирает изделие из новых деталей: сдвигает начало координат в 0 и подвигает центр так, чтобы детали остались на местах в комнате. */
    static Furniture rebuild(Furniture old, List<Part> ps) {
        double mx = Double.MAX_VALUE, my = mx, mz = mx, ex = -mx, ey = ex;
        for (Part q : ps) { mx = Math.min(mx, q.x()); my = Math.min(my, q.y()); mz = Math.min(mz, q.z()); ex = Math.max(ex, q.x() + q.w()); ey = Math.max(ey, q.y() + q.d()); }
        double w1 = ex - mx, d1 = ey - my;
        double sx = mx + (w1 - old.width()) / 2, sy = my + (d1 - old.depth()) / 2;
        double a = Math.toRadians(old.rot()), c = Math.cos(a), s = Math.sin(a);
        List<Part> out = new ArrayList<>();
        for (Part q : ps) out.add(new Part(q.name(), q.w(), q.d(), q.h(), q.x() - mx, q.y() - my, q.z() - mz, q.material()));
        return new Furniture(old.name(), old.x() + sx * c - sy * s, old.y() + sx * s + sy * c, old.rot(), out);
    }

    public static Furniture addPart(Furniture f, Part p) {
        List<Part> l = new ArrayList<>(f.parts()); l.add(p);
        return rebuild(f, l);
    }
    public static Furniture removePart(Furniture f, int i) {
        if (f.parts().size() == 1) throw new IllegalArgumentException("Нельзя удалить последнюю деталь");
        List<Part> l = new ArrayList<>(f.parts()); l.remove(i);
        return rebuild(f, l);
    }
    public static Furniture movePart(Furniture f, int i, double x, double y, double z) {
        List<Part> l = new ArrayList<>(f.parts()); Part o = l.get(i);
        l.set(i, new Part(o.name(), o.w(), o.d(), o.h(), x, y, z, o.material()));
        return rebuild(f, l);
    }
    /** linked=true — соседние детали подстраиваются (resizePart), false — меняется только эта деталь. */
    public static Furniture setPartSize(Furniture f, int i, int axis, double size, boolean linked) {
        if (size <= 0) throw new IllegalArgumentException("Размер должен быть больше нуля");
        if (linked) return rebuild(f, resizePart(f, i, axis, size, false).parts());
        List<Part> l = new ArrayList<>(f.parts()); Part o = l.get(i);
        l.set(i, new Part(o.name(), axis == 0 ? size : o.w(), axis == 1 ? size : o.d(), axis == 2 ? size : o.h(), o.x(), o.y(), o.z(), o.material()));
        return rebuild(f, l);
    }
    public static Furniture setPartMaterial(Furniture f, int i, String mat) {
        if (!Materials.names().contains(mat)) throw new IllegalArgumentException("Неизвестный материал: " + mat);
        List<Part> l = new ArrayList<>(f.parts()); Part o = l.get(i);
        l.set(i, new Part(o.name(), o.w(), o.d(), o.h(), o.x(), o.y(), o.z(), mat));
        return new Furniture(f.name(), f.x(), f.y(), f.rot(), l);
    }
    public static Furniture duplicatePart(Furniture f, int i, double dx, double dy, double dz) {
        Part o = f.parts().get(i);
        return addPart(f, new Part(o.name(), o.w(), o.d(), o.h(), o.x() + dx, o.y() + dy, o.z() + dz, o.material()));
    }
}
