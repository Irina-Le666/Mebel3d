package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Чертежи из той же геометрии, что и 3D: план и развёртки стен (SVG, 1 мм = 0,1 px). */
public final class Drawing {
    private Drawing() {}
    static final double K = 0.1, M = 60;
    static String f(double v) { return String.format(Locale.ROOT, "%.1f", v); }
    static String mm(double v) { return Project.n(Math.round(v)) + " мм"; }

    public static String plan(Project p) {
        Room r = p.room();
        StringBuilder b = head(r.W() * K + 2 * M, r.D() * K + 2 * M);
        b.append("<rect x=\"").append(f(M)).append("\" y=\"").append(f(M)).append("\" width=\"").append(f(r.W() * K)).append("\" height=\"").append(f(r.D() * K))
         .append("\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"3\"/>\n");
        for (Opening o : r.openings()) {
            double x1, y1, x2, y2;
            switch (o.wall()) {
                case 0 -> { x1 = o.offset(); y1 = 0; x2 = o.offset() + o.width(); y2 = 0; }
                case 1 -> { x1 = r.W(); y1 = o.offset(); x2 = r.W(); y2 = o.offset() + o.width(); }
                case 2 -> { x1 = o.offset(); y1 = r.D(); x2 = o.offset() + o.width(); y2 = r.D(); }
                default -> { x1 = 0; y1 = o.offset(); x2 = 0; y2 = o.offset() + o.width(); }
            }
            b.append("<line class=\"opening\" x1=\"").append(f(M + x1 * K)).append("\" y1=\"").append(f(M + y1 * K)).append("\" x2=\"").append(f(M + x2 * K))
             .append("\" y2=\"").append(f(M + y2 * K)).append("\" stroke=\"#1f6fff\" stroke-width=\"6\"/>\n");
        }
        for (Furniture fu : p.items()) {
            StringBuilder pts = new StringBuilder();
            for (double[] c : fu.box().corners()) pts.append(f(M + c[0] * K)).append(',').append(f(M + c[1] * K)).append(' ');
            b.append("<polygon class=\"item\" points=\"").append(pts.toString().trim()).append("\" fill=\"#f1e6d4\" stroke=\"#8a6a3b\"/>\n");
            b.append("<text x=\"").append(f(M + fu.x() * K)).append("\" y=\"").append(f(M + fu.y() * K)).append("\" font-size=\"11\" text-anchor=\"middle\">")
             .append(esc(fu.name())).append(' ').append(Project.n(fu.width())).append('×').append(Project.n(fu.depth())).append("</text>\n");
        }
        for (Fixture x : p.fixtures())
            b.append("<rect class=\"fixture\" x=\"").append(f(M + (x.x() - x.w() / 2) * K)).append("\" y=\"").append(f(M + (x.y() - x.d() / 2) * K)).append("\" width=\"")
             .append(f(x.w() * K)).append("\" height=\"").append(f(x.d() * K)).append("\" fill=\"#e9d5d5\" stroke=\"#b04a4a\"><title>").append(esc(x.kind())).append("</title></rect>\n");
        dimH(b, M, M + r.W() * K, M - 18, mm(r.W()));
        dimV(b, M - 18, M, M + r.D() * K, mm(r.D()) + " (глубина)");
        return b.append("</svg>").toString();
    }

    /** Развёртка стены, вид из комнаты. u — координата вдоль стены слева направо. */
    public static String elevation(Project p, int wall) {
        Room r = p.room();
        double len = wall % 2 == 0 ? r.W() : r.D();
        StringBuilder b = head(len * K + 2 * M, r.H() * K + 2 * M);
        b.append("<rect x=\"").append(f(M)).append("\" y=\"").append(f(M)).append("\" width=\"").append(f(len * K)).append("\" height=\"").append(f(r.H() * K))
         .append("\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"2\"/>\n");
        for (Opening o : r.openings()) if (o.wall() == wall)
            b.append("<rect class=\"opening\" x=\"").append(f(M + o.offset() * K)).append("\" y=\"").append(f(M + (r.H() - o.sill() - o.height()) * K))
             .append("\" width=\"").append(f(o.width() * K)).append("\" height=\"").append(f(o.height() * K)).append("\" fill=\"#dbe8ff\" stroke=\"#1f6fff\"/>\n");
        for (Furniture fu : p.items()) {
            double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE, dist = Double.MAX_VALUE;
            for (double[] c : fu.box().corners()) {
                double u = switch (wall) { case 0 -> c[0]; case 1 -> c[1]; case 2 -> r.W() - c[0]; default -> r.D() - c[1]; };
                double dd = switch (wall) { case 0 -> c[1]; case 1 -> r.W() - c[0]; case 2 -> r.D() - c[1]; default -> c[0]; };
                lo = Math.min(lo, u); hi = Math.max(hi, u); dist = Math.min(dist, dd);
            }
            if (dist > 600) continue;
            double h = fu.height();
            b.append("<rect class=\"item\" x=\"").append(f(M + lo * K)).append("\" y=\"").append(f(M + (r.H() - h) * K)).append("\" width=\"").append(f((hi - lo) * K))
             .append("\" height=\"").append(f(h * K)).append("\" fill=\"#f1e6d4\" stroke=\"#8a6a3b\"/>\n");
            text(b, M + (lo + hi) / 2 * K, M + (r.H() - h) * K - 5, esc(fu.name()) + " " + Project.n(Math.round(hi - lo)) + "×" + Project.n(h));
        }
        dimH(b, M, M + len * K, M - 18, mm(len));
        dimV(b, M - 18, M, M + r.H() * K, mm(r.H()));
        text(b, M + len * K / 2, M + r.H() * K + 35, "Стена " + (wall + 1) + ", высота " + mm(r.H()));
        return b.append("</svg>").toString();
    }

    /** Чертёж изделия: фасад, вид сверху, вид сбоку, размеры и спецификация. */
    public static String furniture(Furniture fu) {
        double W = fu.width(), D = fu.depth(), H = fu.height();
        double s = Math.min(0.25, 420 / Math.max(W + D, H + D)), g = 70;
        double fx = M, fy = M, tx = M, ty = M + H * s + g, sx = M + W * s + g, sy = M;
        List<BomLine> bom = Core.bom(fu);
        double w = M + W * s + g + D * s + M, h = ty + D * s + 40 + 18 * (bom.size() + 2);
        StringBuilder b = head(w, Math.max(h, M + H * s + M));
        for (Part p : fu.parts()) {
            rect(b, fx + p.x() * s, fy + (H - p.z() - p.h()) * s, p.w() * s, p.h() * s);
            rect(b, tx + p.x() * s, ty + p.y() * s, p.w() * s, p.d() * s);
            rect(b, sx + p.y() * s, sy + (H - p.z() - p.h()) * s, p.d() * s, p.h() * s);
        }
        dimH(b, fx, fx + W * s, fy - 18, mm(W));
        dimV(b, fx - 18, fy, fy + H * s, mm(H));
        dimV(b, tx - 18, ty, ty + D * s, mm(D));
        dimH(b, sx, sx + D * s, sy - 18, mm(D));
        text(b, fx + W * s / 2, fy + H * s + 16, "Фасад");
        text(b, tx + W * s / 2, ty + D * s + 16, "Вид сверху");
        text(b, sx + D * s / 2, sy + H * s + 16, "Вид сбоку");
        double y = ty + D * s + 40;
        for (BomLine l : bom) {
            b.append("<text x=\"").append(f(M)).append("\" y=\"").append(f(y)).append("\" font-size=\"12\">")
             .append(esc(l.name())).append(" ×").append(l.qty()).append(": ").append(Project.n(l.a())).append('×').append(Project.n(l.b())).append('×')
             .append(Project.n(l.c())).append(' ').append(esc(l.material())).append("</text>\n");
            y += 18;
        }
        return b.append("</svg>").toString();
    }
    static void rect(StringBuilder b, double x, double y, double w, double h) {
        b.append("<rect class=\"part\" x=\"").append(f(x)).append("\" y=\"").append(f(y)).append("\" width=\"").append(f(w)).append("\" height=\"").append(f(h))
         .append("\" fill=\"#f1e6d4\" stroke=\"#8a6a3b\"/>\n");
    }
    static void dimH(StringBuilder b, double x1, double x2, double y, String t) {
        b.append("<path d=\"M").append(f(x1)).append(' ').append(f(y - 4)).append("v8M").append(f(x2)).append(' ').append(f(y - 4)).append("v8M")
         .append(f(x1)).append(' ').append(f(y)).append("H").append(f(x2)).append("\" stroke=\"#333\" fill=\"none\"/>\n");
        text(b, (x1 + x2) / 2, y - 6, t);
    }
    static void dimV(StringBuilder b, double x, double y1, double y2, String t) {
        b.append("<path d=\"M").append(f(x - 4)).append(' ').append(f(y1)).append("h8M").append(f(x - 4)).append(' ').append(f(y2)).append("h8M")
         .append(f(x)).append(' ').append(f(y1)).append("V").append(f(y2)).append("\" stroke=\"#333\" fill=\"none\"/>\n");
        b.append("<text transform=\"translate(").append(f(x - 6)).append(' ').append(f((y1 + y2) / 2)).append(") rotate(-90)\" font-size=\"12\" text-anchor=\"middle\">")
         .append(t).append("</text>\n");
    }

    /** План всего объекта: помещения на общем плане с проёмами и мебелью. */
    public static String buildingPlan(Building bl) {
        double x0 = Double.MAX_VALUE, y0 = x0, x1 = -x0, y1 = -x0;
        for (Building.Placed p : bl.rooms()) {
            x0 = Math.min(x0, p.ox()); y0 = Math.min(y0, p.oy());
            x1 = Math.max(x1, p.ox() + p.project().room().W()); y1 = Math.max(y1, p.oy() + p.project().room().D());
        }
        if (bl.rooms().isEmpty()) { x0 = y0 = 0; x1 = y1 = 1000; }
        StringBuilder b = head((x1 - x0) * K + 2 * M, (y1 - y0) * K + 2 * M);
        for (Building.Placed p : bl.rooms()) {
            Room r = p.project().room();
            double bx = M + (p.ox() - x0) * K, by = M + (p.oy() - y0) * K;
            b.append("<rect class=\"room\" x=\"").append(f(bx)).append("\" y=\"").append(f(by)).append("\" width=\"").append(f(r.W() * K)).append("\" height=\"").append(f(r.D() * K))
             .append("\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"3\"/>\n");
            for (Opening o : r.openings()) {
                double ax, ay, cx, cy;
                switch (o.wall()) {
                    case 0 -> { ax = o.offset(); ay = 0; cx = o.offset() + o.width(); cy = 0; }
                    case 1 -> { ax = r.W(); ay = o.offset(); cx = r.W(); cy = o.offset() + o.width(); }
                    case 2 -> { ax = o.offset(); ay = r.D(); cx = o.offset() + o.width(); cy = r.D(); }
                    default -> { ax = 0; ay = o.offset(); cx = 0; cy = o.offset() + o.width(); }
                }
                b.append("<line class=\"opening\" x1=\"").append(f(bx + ax * K)).append("\" y1=\"").append(f(by + ay * K)).append("\" x2=\"").append(f(bx + cx * K))
                 .append("\" y2=\"").append(f(by + cy * K)).append("\" stroke=\"#1f6fff\" stroke-width=\"6\"/>\n");
            }
            for (Furniture fu : p.project().items()) {
                StringBuilder pts = new StringBuilder();
                for (double[] c : fu.box().corners()) pts.append(f(bx + c[0] * K)).append(',').append(f(by + c[1] * K)).append(' ');
                b.append("<polygon class=\"item\" points=\"").append(pts.toString().trim()).append("\" fill=\"#f1e6d4\" stroke=\"#8a6a3b\"/>\n");
            }
            text(b, bx + r.W() * K / 2, by + 16, esc(p.project().name()) + ", " + String.format(Locale.ROOT, "%.1f", r.W() * r.D() / 1e6) + " м²");
        }
        return b.append("</svg>").toString();
    }

    /** Текстовая спецификация проекта: детали каждого изделия и ведомость материалов. */
    public static String specification(Project p) {
        StringBuilder b = new StringBuilder("Спецификация: " + p.name() + "\n");
        Map<String, Double> total = new TreeMap<>();
        for (Furniture fu : p.items()) {
            b.append("\n").append(fu.name()).append(' ').append(Project.n(Math.round(fu.width()))).append('×').append(Project.n(Math.round(fu.depth()))).append('×')
             .append(Project.n(Math.round(fu.height()))).append(" мм\n");
            for (BomLine l : Core.bom(fu))
                b.append("  ").append(l.name()).append(" ×").append(l.qty()).append(": ").append(Project.n(Math.round(l.a()))).append('×').append(Project.n(Math.round(l.b())))
                 .append('×').append(Project.n(Math.round(l.c()))).append(' ').append(l.material()).append('\n');
            Core.materialAreaM2(fu).forEach((k, v) -> total.merge(k, v, Double::sum));
        }
        b.append("\nВедомость материалов (площадь больших граней деталей, без кромки и запаса):\n");
        total.forEach((k, v) -> b.append("  ").append(k).append(": ").append(String.format(Locale.ROOT, "%.2f", v)).append(" м²\n"));
        return b.toString();
    }

    static StringBuilder head(double w, double h) {
        return new StringBuilder("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " + f(w) + " " + f(h) + "\" font-family=\"sans-serif\">\n");
    }
    static void text(StringBuilder b, double x, double y, String t) {
        b.append("<text x=\"").append(f(x)).append("\" y=\"").append(f(y)).append("\" font-size=\"12\" text-anchor=\"middle\">").append(t).append("</text>\n");
    }
    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;"); }
}
