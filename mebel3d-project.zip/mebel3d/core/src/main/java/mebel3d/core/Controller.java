package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Логика экрана без Android: выбор, перенос, правка размеров, каталог, отмена. Интерфейс только вызывает эти методы. */
public final class Controller {
    private final Project.History hist;
    private Project live;
    private int sel = -1;
    private int selPart = -1;
    private int selOp = -1, selFx = -1;
    private final Set<Integer> multi = new LinkedHashSet<>();
    private List<Integer> dragMembers = List.of();
    private Map<Integer, double[]> dragStart = new HashMap<>();
    /** Допуск привязки к стенам и граням других предметов, мм. */
    public static final double SNAP = 60;
    private double offX, offY;

    public Controller(Project p) { hist = new Project.History(p); }
    public Project project() { return live != null ? live : hist.current(); }
    public int selected() { return sel; }
    public Furniture selectedItem() { return sel >= 0 ? project().items().get(sel) : null; }
    public void select(int i) { int n = i >= 0 && i < project().items().size() ? i : -1; if (n != sel) selPart = -1; sel = n; if (n >= 0) { selOp = -1; selFx = -1; } else { selOp = -1; selFx = -1; } }
    /** 0 — ничего, 1 — изделие, 2 — проём, 3 — инженерный элемент. */
    public int kind() { return sel >= 0 ? 1 : selOp >= 0 ? 2 : selFx >= 0 ? 3 : 0; }
    public void selectOpening(int i) { select(-1); selOp = i >= 0 && i < project().room().openings().size() ? i : -1; }
    public void selectFixture(int i) { select(-1); selFx = i >= 0 && i < project().fixtures().size() ? i : -1; }
    public int selectedOpeningIndex() { return selOp; }
    public int selectedFixtureIndex() { return selFx; }
    public Core.Opening selectedOpening() { return selOp >= 0 ? project().room().openings().get(selOp) : null; }
    public Fixture selectedFixture() { return selFx >= 0 ? project().fixtures().get(selFx) : null; }
    public Set<Integer> multi() { return multi; }
    public void toggleMulti(int i) { if (!multi.remove(i) && i >= 0 && i < project().items().size()) multi.add(i); }
    public void clearMulti() { multi.clear(); }
    public int selectedPart() { return selPart; }
    public void selectPart(int i) { Furniture f = selectedItem(); selPart = f != null && i >= 0 && i < f.parts().size() ? i : -1; }
    public Part selectedPartItem() { return selPart >= 0 ? selectedItem().parts().get(selPart) : null; }
    public List<String> warnings() { return project().warnings(); }

    static boolean contains(Furniture f, double x, double y) {
        double a = Math.toRadians(-f.rot()), c = Math.cos(a), s = Math.sin(a), dx = x - f.x(), dy = y - f.y();
        return Math.abs(dx * c - dy * s) <= f.width() / 2 && Math.abs(dx * s + dy * c) <= f.depth() / 2;
    }
    /** Верхний предмет под точкой плана или -1. */
    public int hit(double x, double y) {
        List<Furniture> l = project().items();
        for (int i = l.size() - 1; i >= 0; i--) if (contains(l.get(i), x, y)) return i;
        return -1;
    }

    private void commit(Project p) { if (!p.equals(project())) hist.apply(p); }

    public void beginDrag(int i, double gx, double gy) {
        select(i);
        if (sel < 0) return;
        Furniture f = selectedItem(); offX = f.x() - gx; offY = f.y() - gy; live = hist.current();
        dragMembers = new ArrayList<>(project().membersOf(sel));
        dragStart = new HashMap<>();
        for (int m : dragMembers) dragStart.put(m, new double[]{live.items().get(m).x(), live.items().get(m).y()});
    }

    /** Полуразмеры габарита изделия с учётом поворота. */
    private static double[] half(Furniture f) {
        double mnx = Double.MAX_VALUE, mny = mnx, mxx = -mnx, mxy = -mnx;
        for (double[] c : f.moved(0, 0).box().corners()) { mnx = Math.min(mnx, c[0]); mxx = Math.max(mxx, c[0]); mny = Math.min(mny, c[1]); mxy = Math.max(mxy, c[1]); }
        return new double[]{(mxx - mnx) / 2, (mxy - mny) / 2};
    }
    /** Привязка центра изделия: левая и правая грани к стенам и граням других предметов (кроме своей группы). */
    private double[] snap(int i, double nx, double ny, List<Integer> skip) {
        Project p = hist.current(); Room r = p.room();
        double[] h = half(p.items().get(i));
        List<double[]> xs = new ArrayList<>(), ys = new ArrayList<>();
        xs.add(new double[]{0}); xs.add(new double[]{r.W()}); ys.add(new double[]{0}); ys.add(new double[]{r.D()});
        for (int k = 0; k < p.items().size(); k++) {
            if (skip.contains(k)) continue;
            double[] oh = half(p.items().get(k)); Furniture o = p.items().get(k);
            xs.add(new double[]{o.x() - oh[0]}); xs.add(new double[]{o.x() + oh[0]});
            ys.add(new double[]{o.y() - oh[1]}); ys.add(new double[]{o.y() + oh[1]});
        }
        return new double[]{nx + best(xs, nx, h[0]), ny + best(ys, ny, h[1])};
    }
    private static double best(List<double[]> targets, double c, double half) {
        double adj = 0, min = SNAP + 1;
        for (double[] t : targets) for (double edge : new double[]{c - half, c + half}) {
            double d = t[0] - edge;
            if (Math.abs(d) < min) { min = Math.abs(d); adj = d; }
        }
        return min <= SNAP ? adj : 0;
    }

    public void dragTo(double gx, double gy, double grid) {
        if (live == null || sel < 0) return;
        double[] s = snap(sel, Math.round((gx + offX) / grid) * grid, Math.round((gy + offY) / grid) * grid, dragMembers);
        double dx = s[0] - dragStart.get(sel)[0], dy = s[1] - dragStart.get(sel)[1];
        Project p = hist.current();
        for (int m : dragMembers) { double[] st = dragStart.get(m); p = p.replace(m, p.items().get(m).moved(st[0] + dx, st[1] + dy)); }
        live = p;
    }
    public void endDrag() { Project p = live; live = null; if (p != null) commit(p); }

    public void setPosition(double x, double y) {
        if (sel < 0) return;
        Furniture f = selectedItem();
        commit(Editor.moveItems(project(), project().membersOf(sel), x - f.x(), y - f.y()));
    }
    public void setRotation(double deg) {
        if (sel < 0) return;
        List<Integer> m = project().membersOf(sel);
        if (m.size() == 1) commit(project().replace(sel, selectedItem().rotated(deg)));
        else commit(Editor.rotateItems(project(), m, deg - selectedItem().rot()));
    }
    public void setSize(double W, double D, double H) { if (sel >= 0) commit(project().replace(sel, Editor.setOverallSize(selectedItem(), W, D, H))); }
    public void setMaterial(String name) { if (sel >= 0) commit(project().replace(sel, Materials.replaceMain(selectedItem(), name))); }
    public void resizePart(int part, int axis, double size, boolean anchorMax) { if (sel >= 0) commit(project().replace(sel, Editor.resizePart(selectedItem(), part, axis, size, anchorMax))); }

    public void add(String catalogName) {
        Room r = project().room();
        commit(project().add(Catalog.create(catalogName).moved(r.W() / 2, r.D() / 2)));
        sel = project().items().size() - 1;
    }
    public void duplicate() {
        if (sel < 0) return;
        Furniture f = selectedItem();
        commit(project().add(f.moved(f.x() + 300, f.y() + 300)));
        sel = project().items().size() - 1;
    }
    public void deleteSelected() { if (sel >= 0) { commit(project().remove(sel)); sel = -1; selPart = -1; } }
    public void undo() { if (hist.undo()) fixSel(); }
    public void redo() { if (hist.redo()) fixSel(); }
    private void fixSel() {
        if (sel >= 0) select(Math.min(sel, project().items().size() - 1));
        if (selOp >= project().room().openings().size()) selOp = -1;
        if (selFx >= project().fixtures().size()) selFx = -1;
        multi.clear();
    }
    // ---- помещение, проёмы, инженерные элементы ----
    public void setRoom(double W, double D, double H, double wallT) {
        if (W <= 0 || D <= 0 || H <= 0 || wallT <= 0 || 2 * wallT >= Math.min(W, D)) throw new IllegalArgumentException("Недопустимые размеры помещения");
        Room r = new Room(W, D, H, wallT, project().room().openings());
        List<String> e = r.validate();
        if (!e.isEmpty()) throw new IllegalArgumentException(e.get(0));
        commit(project().withRoom(r));
    }
    /** Добавляет окно или дверь на первое свободное место на любой стене. */
    public boolean addOpening(String kind) {
        Room r = project().room();
        double w = kind.equals("Дверь") ? 900 : 1500, h = kind.equals("Дверь") ? 2100 : 1400, sill = kind.equals("Дверь") ? 0 : 900;
        for (int wall = 0; wall < 4; wall++)
            for (double off = 300; off + w <= (wall % 2 == 0 ? r.W() : r.D()) - 300 + 1e-9; off += 100) {
                List<Opening> l = new ArrayList<>(r.openings()); l.add(new Opening(wall, off, w, h, sill));
                Room n = new Room(r.W(), r.D(), r.H(), r.wallT(), l);
                if (n.validate().isEmpty()) { commit(project().withRoom(n)); return true; }
            }
        return false;
    }
    public void removeOpening(int i) {
        Room r = project().room(); List<Opening> l = new ArrayList<>(r.openings()); l.remove(i);
        commit(project().withRoom(new Room(r.W(), r.D(), r.H(), r.wallT(), l)));
    }
    public void addFixture(String kind) { Room r = project().room(); commit(project().addFixture(Catalog.fixture(kind, r.W(), r.D()))); }
    public void moveFixture(int i, double x, double y) { Fixture f = project().fixtures().get(i); commit(project().replaceFixture(i, new Fixture(f.kind(), x, y, f.w(), f.d(), f.z(), f.h()))); }
    public void removeFixture(int i) { commit(project().removeFixture(i)); }

    // ---- конструктор: детали выбранного изделия ----
    private void editItem(Furniture f) { commit(project().replace(sel, f)); }
    public void addPart(String name, double w, double d, double h, double x, double y, double z, String material) {
        if (sel < 0) return;
        if (!Materials.names().contains(material)) throw new IllegalArgumentException("Неизвестный материал: " + material);
        editItem(Editor.addPart(selectedItem(), new Part(name, w, d, h, x, y, z, material)));
        selPart = selectedItem().parts().size() - 1;
    }
    public void removePart() { if (sel >= 0 && selPart >= 0) { editItem(Editor.removePart(selectedItem(), selPart)); selPart = -1; } }
    public void setPartSize(int axis, double size, boolean linked) { if (sel >= 0 && selPart >= 0) editItem(Editor.setPartSize(selectedItem(), selPart, axis, size, linked)); }
    public void setPartPosition(double x, double y, double z) { if (sel >= 0 && selPart >= 0) editItem(Editor.movePart(selectedItem(), selPart, x, y, z)); }
    public void setPartMaterial(String m) { if (sel >= 0 && selPart >= 0) editItem(Editor.setPartMaterial(selectedItem(), selPart, m)); }
    public void duplicatePart(double dx, double dy, double dz) {
        if (sel >= 0 && selPart >= 0) { editItem(Editor.duplicatePart(selectedItem(), selPart, dx, dy, dz)); selPart = selectedItem().parts().size() - 1; }
    }

    // ---- фото помещения ----
    public List<Photos.Photo> photos() { return project().photos(); }
    public void addPhoto(String name, String uri) { commit(project().addPhoto(Photos.Photo.of(name, uri))); }
    public void removePhoto(int i) { commit(project().removePhoto(i)); }
    public void calibratePhoto(int i, double ax, double ay, double bx, double by, double mm) { commit(project().replacePhoto(i, photos().get(i).calibrate(ax, ay, bx, by, mm))); }
    public void bindPhoto(int i, int wall, double originX, double floorY) { commit(project().replacePhoto(i, photos().get(i).bind(wall, originX, floorY))); }
    public void addMark(int i, String kind, double x1, double y1, double x2, double y2) { commit(project().replacePhoto(i, photos().get(i).addMark(kind, x1, y1, x2, y2))); }
    public void removeMark(int i, int mark) { commit(project().replacePhoto(i, photos().get(i).removeMark(mark))); }
    /** Переносит отметку фото в модель: окно или дверь — в проёмы стены, остальное — в инженерные элементы. */
    public void applyMark(int i, int mark) {
        Photos.Photo ph = photos().get(i);
        String kind = ph.marks().get(mark).kind();
        if (kind.equals("Окно") || kind.equals("Дверь")) {
            Core.Opening o = Photos.openingFrom(ph, mark, project().room());
            Core.Room r = project().room(); List<Core.Opening> l = new ArrayList<>(r.openings()); l.add(o);
            commit(project().withRoom(new Core.Room(r.W(), r.D(), r.H(), r.wallT(), l)));
        } else commit(project().addFixture(Photos.fixtureFrom(ph, mark, project().room())));
    }

    // ---- группы, проёмы и инженерные элементы по выбору ----
    public void rename(String n) { commit(project().withName(n)); }
    public void groupMulti(String name) { commit(project().group(name, new ArrayList<>(multi))); multi.clear(); }
    public void ungroupSelected() { if (sel >= 0) commit(project().ungroup(sel)); }
    public void updateOpening(int i, double offset, double width, double height, double sill) {
        Room r = project().room(); Core.Opening o = r.openings().get(i);
        List<Core.Opening> l = new ArrayList<>(r.openings()); l.set(i, new Core.Opening(o.wall(), offset, width, height, sill));
        Room n = new Room(r.W(), r.D(), r.H(), r.wallT(), l);
        List<String> e = n.validate();
        if (!e.isEmpty()) throw new IllegalArgumentException(e.get(0));
        commit(project().withRoom(n));
    }
    public void updateFixture(int i, double x, double y, double w, double d, double z, double h) {
        Fixture f = project().fixtures().get(i);
        commit(project().replaceFixture(i, new Fixture(f.kind(), x, y, w, d, z, h)));
    }
    /** Удаляет то, что выбрано: изделие, проём или инженерный элемент. */
    public void removeSelected() {
        if (sel >= 0) deleteSelected();
        else if (selOp >= 0) { int i = selOp; selOp = -1; removeOpening(i); }
        else if (selFx >= 0) { int i = selFx; selFx = -1; removeFixture(i); }
    }

    public String toJson() { return project().toJson(); }
}
