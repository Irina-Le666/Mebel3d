package mebel3d.core;

import mebel3d.core.Core.*;
import java.util.*;

/** Фото существующего помещения: калибровка по известному размеру, привязка к стене, отметки. Координаты — пиксели исходного снимка. */
public final class Photos {
    private Photos() {}

    public record Mark(String kind, double x1, double y1, double x2, double y2) {}

    /**
     * Фото одной стены. Калибровка: две точки (a, b) на плоскости стены и расстояние между ними.
     * Привязка: стена комнаты (0..3), пиксель левого угла стены (originX) и линии пола (floorY).
     * Неустановленные значения: knownMm = 0, wall = -1, originX/floorY = -1.
     */
    public record Photo(String name, String uri, int wall, double calAx, double calAy, double calBx, double calBy,
                        double knownMm, double originX, double floorY, List<Mark> marks) {
        public Photo { marks = List.copyOf(marks); }
        public static Photo of(String name, String uri) { return new Photo(name, uri, -1, 0, 0, 0, 0, 0, -1, -1, List.of()); }

        public boolean calibrated() { return knownMm > 0 && Math.hypot(calBx - calAx, calBy - calAy) > 0; }
        public boolean bound() { return wall >= 0 && wall <= 3 && originX >= 0 && floorY >= 0; }
        public double mmPerPx() {
            if (!calibrated()) throw new IllegalArgumentException("Фото не откалибровано: отметьте две точки и введите расстояние");
            return knownMm / Math.hypot(calBx - calAx, calBy - calAy);
        }

        public Photo calibrate(double ax, double ay, double bx, double by, double mm) {
            if (mm <= 0) throw new IllegalArgumentException("Расстояние должно быть больше нуля");
            if (Math.hypot(bx - ax, by - ay) < 5) throw new IllegalArgumentException("Точки слишком близко друг к другу");
            return new Photo(name, uri, wall, ax, ay, bx, by, mm, originX, floorY, marks);
        }
        public Photo bind(int w, double ox, double fy) {
            if (w < 0 || w > 3) throw new IllegalArgumentException("Стена должна быть от 1 до 4");
            if (ox < 0 || fy < 0) throw new IllegalArgumentException("Точка вне снимка");
            return new Photo(name, uri, w, calAx, calAy, calBx, calBy, knownMm, ox, fy, marks);
        }
        public Photo addMark(String kind, double x1, double y1, double x2, double y2) {
            if (!markKinds().contains(kind)) throw new IllegalArgumentException("Неизвестный тип отметки: " + kind);
            double a = Math.min(x1, x2), b = Math.min(y1, y2), c = Math.max(x1, x2), d = Math.max(y1, y2);
            if (c - a < 2 || d - b < 2) throw new IllegalArgumentException("Рамка слишком маленькая");
            List<Mark> l = new ArrayList<>(marks); l.add(new Mark(kind, a, b, c, d));
            return new Photo(name, uri, wall, calAx, calAy, calBx, calBy, knownMm, originX, floorY, l);
        }
        public Photo removeMark(int i) {
            List<Mark> l = new ArrayList<>(marks); l.remove(i);
            return new Photo(name, uri, wall, calAx, calAy, calBx, calBy, knownMm, originX, floorY, l);
        }
    }

    public static List<String> markKinds() { return List.of("Окно", "Дверь", "Розетка", "Радиатор", "Труба"); }

    private static void needReady(Photo p) {
        p.mmPerPx();
        if (!p.bound()) throw new IllegalArgumentException("Фото не привязано к стене: укажите стену и точку угла на полу");
    }

    /** Окно или дверь из отметки: положение и размеры в мм считаются от угла стены и линии пола. */
    public static Opening openingFrom(Photo p, int mark, Room room) {
        needReady(p);
        Mark m = p.marks().get(mark);
        if (!m.kind().equals("Окно") && !m.kind().equals("Дверь")) throw new IllegalArgumentException("Отметка «" + m.kind() + "» не проём");
        double k = p.mmPerPx();
        double sill = Math.max(0, (p.floorY() - m.y2()) * k);
        Opening o = new Opening(p.wall(), (m.x1() - p.originX()) * k, (m.x2() - m.x1()) * k, (m.y2() - m.y1()) * k, sill);
        List<Opening> l = new ArrayList<>(room.openings()); l.add(o);
        List<String> e = new Room(room.W(), room.D(), room.H(), room.wallT(), l).validate();
        if (!e.isEmpty()) throw new IllegalArgumentException(e.get(0));
        return o;
    }

    /** Коммуникация из отметки: элемент у стены толщиной 50 мм, отметка по высоте — от пола. */
    public static Fixture fixtureFrom(Photo p, int mark, Room room) {
        needReady(p);
        Mark m = p.marks().get(mark);
        if (m.kind().equals("Окно") || m.kind().equals("Дверь")) throw new IllegalArgumentException("Отметка «" + m.kind() + "» не инженерный элемент");
        double k = p.mmPerPx(), off = (m.x1() - p.originX()) * k, w = (m.x2() - m.x1()) * k, h = (m.y2() - m.y1()) * k;
        double z = Math.max(0, (p.floorY() - m.y2()) * k), mid = off + w / 2, t = 50;
        double len = p.wall() % 2 == 0 ? room.W() : room.D();
        if (off < 0 || off + w > len + 1e-6) throw new IllegalArgumentException("Элемент выходит за стену");
        switch (p.wall()) {
            case 0: return new Fixture(m.kind(), mid, t / 2, w, t, z, h);
            case 1: return new Fixture(m.kind(), room.W() - t / 2, mid, t, w, z, h);
            case 2: return new Fixture(m.kind(), mid, room.D() - t / 2, w, t, z, h);
            default: return new Fixture(m.kind(), t / 2, mid, t, w, z, h);
        }
    }
}
