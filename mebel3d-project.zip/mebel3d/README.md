# Мебель 3D

Проектирование помещений и мебели на Android. Единицы — миллиметры, тема светлая, альбомная ориентация.

- `core/` — геометрическое ядро (Java 17, без Android): помещения и проёмы, мебель из деталей, параметрический шкаф,
  каталог с поиском, столкновения и привязки, группы, инженерные элементы, фото с калибровкой, несколько помещений,
  чертежи SVG и спецификация, сохранение JSON, отмена/повтор. Проверено тестами: `core/src/test`.
- `app/` — приложение Android (Kotlin). Код написан, НЕ собирался и НЕ запускался. Вся логика экрана находится в `core/Controller`.
- `STATUS.md` — честная таблица статусов по каждой функции ТЗ и чек-лист первого запуска.

## Тесты ядра без Gradle
    cd core && mkdir -p out && javac -encoding UTF-8 -d out $(find src -name '*.java')
    for t in CoreTest ProjectTest BuildingTest EditorTest ControllerTest FixtureTest MaterialsTest ConstructorTest PhotoTest BlockTest; do java -ea -cp out mebel3d.core.$t; done

## Как получить APK без Android Studio
1. Создать репозиторий на github.com и загрузить в него содержимое этой папки (включая скрытую папку `.github`).
2. Вкладка Actions -> «Сборка APK» -> Run workflow (или любой коммит в main).
3. Через 5–10 минут во вкладке Releases появится «Сборка N» с файлом `mebel3d.apk` — это прямая ссылка на скачивание.
Сборка сначала прогоняет тесты ядра, затем собирает APK.
