package ru.mebel3d

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import mebel3d.core.Controller
import mebel3d.core.Materials
import kotlin.math.*

/** Изометрический вид и вид сверху. Вся логика выбора и правки — в Controller; здесь рисование и касания. */
class SceneView(ctx: Context, var ctl: Controller, private val onChange: () -> Unit) : View(ctx) {
    var plan = false          // true — вид сверху (2D)
    var partMode = false      // касание выбирает деталь выбранного изделия
    var multiMode = false     // касание добавляет изделие к выбору для группы
    var light = 0             // 0 день, 1 вечер, 2 ночь
    var grid = 50.0
    /** Состояние каждой стены: 0 авто (дальние видны, ближние снижены), 1 скрыта, 2 прозрачная, 3 видна. */
    val wallState = IntArray(4)

    private var yaw = -0.6
    private var zoom = 1.0
    private var lastX = 0f
    private var mode = 0      // 1 — вращение, 2 — перенос изделия
    private class Hit(val kind: Int, val index: Int, val part: Int, val polys: List<List<PointF>>)
    private val hits = ArrayList<Hit>()
    private fun paint(w: Float, col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = w; color = col }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = paint(2f, 0xFF8A94A8.toInt())
    private val selEdge = paint(6f, 0xFF1F6FFF.toInt())
    private val partEdge = paint(7f, 0xFFFF8A00.toInt())
    private val multiEdge = paint(5f, 0xFF12A594.toInt())
    private val badEdge = paint(5f, 0xFFD23B3B.toInt())
    private val groupEdge = paint(4f, 0xFF8E4EC6.toInt())
    private val grain = paint(1.5f, 0x55000000)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; color = 0xFF1B2433.toInt(); textAlign = Paint.Align.CENTER }
    private var k = 0.1; private var ox = 0.0; private var oy = 0.0
    private val lf get() = floatArrayOf(1f, 0.8f, 0.55f)[light]
    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoom = (zoom * d.scaleFactor).coerceIn(0.4, 3.0); invalidate(); return true }
    })

    fun resetView() { yaw = -0.6; zoom = 1.0; invalidate() }

    private fun rot(x: Double, y: Double): Pair<Double, Double> {
        val r = ctl.project().room(); val dx = x - r.W() / 2; val dy = y - r.D() / 2
        return Pair(dx * cos(yaw) - dy * sin(yaw), dx * sin(yaw) + dy * cos(yaw))
    }
    private fun depth(x: Double, y: Double) = rot(x, y).let { it.first + it.second }
    private fun p(x: Double, y: Double, z: Double): PointF {
        if (plan) { val r = ctl.project().room(); return PointF((ox + (x - r.W() / 2) * k).toFloat(), (oy + (y - r.D() / 2) * k).toFloat()) }
        val (rx, ry) = rot(x, y)
        return PointF((ox + (rx - ry) * 0.866 * k).toFloat(), (oy + (rx + ry) * 0.5 * k - z * k).toFloat())
    }
    /** Точка экрана -> точка пола. */
    private fun ground(sx: Float, sy: Float): Pair<Double, Double> {
        val r = ctl.project().room()
        if (plan) return Pair((sx - ox) / k + r.W() / 2, (sy - oy) / k + r.D() / 2)
        val a = (sx - ox) / (0.866 * k); val b = (sy - oy) / (0.5 * k)
        val rx = (a + b) / 2; val ry = (b - a) / 2
        return Pair(rx * cos(yaw) + ry * sin(yaw) + r.W() / 2, -rx * sin(yaw) + ry * cos(yaw) + r.D() / 2)
    }
    private fun inPoly(pts: List<PointF>, x: Float, y: Float): Boolean {
        var c = false; var j = pts.size - 1
        for (i in pts.indices) {
            val a = pts[i]; val b = pts[j]
            if ((a.y > y) != (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) c = !c
            j = i
        }
        return c
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        if (scale.isInProgress || e.pointerCount > 1) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; mode = 0
                val hit = hits.lastOrNull { h -> h.polys.any { inPoly(it, e.x, e.y) } }
                when {
                    hit == null -> { ctl.select(-1); mode = 1 }
                    hit.kind == 2 -> ctl.selectOpening(hit.index)
                    hit.kind == 3 -> ctl.selectFixture(hit.index)
                    multiMode -> ctl.toggleMulti(hit.index)
                    partMode && hit.index == ctl.selected() -> ctl.selectPart(hit.part)
                    else -> { val g = ground(e.x, e.y); ctl.beginDrag(hit.index, g.first, g.second); mode = 2 }
                }
                onChange()
            }
            MotionEvent.ACTION_MOVE -> when (mode) {
                2 -> { val g = ground(e.x, e.y); ctl.dragTo(g.first, g.second, grid); invalidate() }
                1 -> if (!plan) { yaw += (e.x - lastX) * 0.008; lastX = e.x; invalidate() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (mode == 2) ctl.endDrag(); mode = 0; onChange() }
        }
        return true
    }

    private fun shade(color: Int, f: Float): Int {
        val m = f * lf
        return Color.rgb((Color.red(color) * m).toInt().coerceIn(0, 255), (Color.green(color) * m).toInt().coerceIn(0, 255), (Color.blue(color) * m).toInt().coerceIn(0, 255))
    }
    private fun path(pts: List<PointF>) = Path().apply { pts.forEachIndexed { i, q -> if (i == 0) moveTo(q.x, q.y) else lineTo(q.x, q.y) }; close() }
    private fun poly(c: Canvas, pts: List<PointF>, color: Int, stroke: Paint = edge) {
        val pa = path(pts); fill.color = color; c.drawPath(pa, fill); c.drawPath(pa, stroke)
    }
    /** Простая текстура: штрихи вдоль дерева, сетка для ткани. */
    private fun texture(c: Canvas, pts: List<PointF>, kind: String) {
        if (kind == "гладкая" || pts.size < 4) return
        c.save(); c.clipPath(path(pts))
        val a = pts[0]; val b = pts[1]; val d = pts[3]
        val n = if (kind == "дерево") 7 else 10
        for (i in 1 until n) {
            val t = i.toFloat() / n
            c.drawLine(a.x + (d.x - a.x) * t, a.y + (d.y - a.y) * t, b.x + (d.x - a.x) * t, b.y + (d.y - a.y) * t, grain)
            if (kind == "ткань") c.drawLine(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, d.x + (b.x - a.x) * t, d.y + (b.y - a.y) * t, grain)
        }
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(shade(0xFFEEF2F8.toInt(), 1f))
        hits.clear()
        val pr = ctl.project(); val r = pr.room(); val W = r.W(); val D = r.D(); val H = r.H()
        if (plan) { k = min(width * 0.9 / W, height * 0.9 / D) * zoom; ox = width / 2.0; oy = height / 2.0 }
        else { k = min(width * 0.8 / ((W + D) * 0.866), height * 0.8 / ((W + D) * 0.5 + H)) * zoom; ox = width / 2.0; oy = height / 2.0 + H * k * 0.3 }
        val fl = listOf(0.0 to 0.0, W to 0.0, W to D, 0.0 to D)
        poly(c, fl.map { p(it.first, it.second, 0.0) }, shade(0xFFD7B98C.toInt(), 1f))

        // стены
        val wm = IntArray(4)
        for (i in 0..3) {
            val a = fl[i]; val b = fl[(i + 1) % 4]
            val far = depth((a.first + b.first) / 2, (a.second + b.second) / 2) < 0
            wm[i] = if (wallState[i] == 0) (if (far) 3 else 1) else wallState[i]
            if (plan) continue
            when (wm[i]) {
                1 -> poly(c, listOf(p(a.first, a.second, 0.0), p(b.first, b.second, 0.0), p(b.first, b.second, 120.0), p(a.first, a.second, 120.0)), shade(0xFFF4F1EC.toInt(), 0.9f))
                2 -> poly(c, listOf(p(a.first, a.second, 0.0), p(b.first, b.second, 0.0), p(b.first, b.second, H), p(a.first, a.second, H)), Color.argb(70, 200, 210, 230))
                else -> poly(c, listOf(p(a.first, a.second, 0.0), p(b.first, b.second, 0.0), p(b.first, b.second, H), p(a.first, a.second, H)), shade(0xFFF4F1EC.toInt(), 0.97f - i * 0.03f))
            }
        }

        // проёмы
        for ((oi, o) in r.openings().withIndex()) {
            val q = when (o.wall()) {
                0 -> doubleArrayOf(o.offset(), 0.0, o.offset() + o.width(), 0.0)
                1 -> doubleArrayOf(W, o.offset(), W, o.offset() + o.width())
                2 -> doubleArrayOf(o.offset(), D, o.offset() + o.width(), D)
                else -> doubleArrayOf(0.0, o.offset(), 0.0, o.offset() + o.width())
            }
            val selO = ctl.selectedOpeningIndex() == oi
            val polys = ArrayList<List<PointF>>()
            if (plan) {
                val a = p(q[0], q[1], 0.0); val b = p(q[2], q[3], 0.0)
                c.drawLine(a.x, a.y, b.x, b.y, if (selO) selEdge else paint(8f, 0xFF1F6FFF.toInt()))
                val nx = doubleArrayOf(0.0, -1.0, 0.0, 1.0)[o.wall()] * 200; val ny = doubleArrayOf(1.0, 0.0, -1.0, 0.0)[o.wall()] * 200
                polys.add(listOf(a, b, p(q[2] + nx, q[3] + ny, 0.0), p(q[0] + nx, q[1] + ny, 0.0)))
            } else if (wm[o.wall()] >= 2) {
                val quad = listOf(p(q[0], q[1], o.sill()), p(q[2], q[3], o.sill()), p(q[2], q[3], o.sill() + o.height()), p(q[0], q[1], o.sill() + o.height()))
                poly(c, quad, shade(0xFFDBE8FF.toInt(), 1f), if (selO) selEdge else edge); polys.add(quad)
            }
            if (polys.isNotEmpty()) hits.add(Hit(2, oi, -1, polys))
        }

        // инженерные элементы
        for ((fi, x) in pr.fixtures().withIndex()) {
            val box = x.box(); val cs = box.corners(); val cd = depth(x.x(), x.y())
            val lamp = x.kind() == "Светильник"
            val selF = ctl.selectedFixtureIndex() == fi
            val col = if (lamp) 0xFFFFE9A8.toInt() else 0xFFD9B0B0.toInt()
            if (lamp && light > 0) { val g = p(x.x(), x.y(), 0.0); fill.color = Color.argb(70, 255, 210, 120); c.drawCircle(g.x, g.y, (1300 * k).toFloat(), fill) }
            val polys = ArrayList<List<PointF>>()
            for (e in 0..3) {
                val a = cs[e]; val b = cs[(e + 1) % 4]
                if (plan || depth((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) <= cd) continue
                val side = listOf(p(a[0], a[1], box.z0()), p(b[0], b[1], box.z0()), p(b[0], b[1], box.z0() + box.h()), p(a[0], a[1], box.z0() + box.h()))
                poly(c, side, shade(col, 0.85f), if (selF) selEdge else edge); polys.add(side)
            }
            val top = cs.map { p(it[0], it[1], box.z0() + box.h()) }
            poly(c, top, shade(col, 1.05f), if (selF) selEdge else edge); polys.add(top)
            hits.add(Hit(3, fi, -1, polys))
        }

        // мебель по деталям
        val bad = pr.collidingItems()
        val selGroup = if (ctl.selected() >= 0) pr.membersOf(ctl.selected()) else emptyList<Int>()
        fun stroke(idx: Int, pi: Int): Paint = when {
            idx == ctl.selected() && pi == ctl.selectedPart() -> partEdge
            idx == ctl.selected() -> selEdge
            ctl.multi().contains(idx) -> multiEdge
            bad.contains(idx) -> badEdge
            selGroup.contains(idx) -> groupEdge
            else -> edge
        }
        for ((idx, f) in pr.items().withIndex().sortedBy { depth(it.value.x(), it.value.y()) }) {
            val ang = Math.toRadians(f.rot()); val ca = cos(ang); val sa = sin(ang)
            val cxl = f.width() / 2; val cyl = f.depth() / 2
            fun wx(lx: Double, ly: Double) = f.x() + (lx - cxl) * ca - (ly - cyl) * sa
            fun wy(lx: Double, ly: Double) = f.y() + (lx - cxl) * sa + (ly - cyl) * ca
            val order = f.parts().withIndex().sortedBy { depth(wx(it.value.x() + it.value.w() / 2, it.value.y() + it.value.d() / 2), wy(it.value.x() + it.value.w() / 2, it.value.y() + it.value.d() / 2)) }
            for ((pi, q) in order) {
                val pc = listOf(0.0 to 0.0, 1.0 to 0.0, 1.0 to 1.0, 0.0 to 1.0).map { Pair(wx(q.x() + it.first * q.w(), q.y() + it.second * q.d()), wy(q.x() + it.first * q.w(), q.y() + it.second * q.d())) }
                val cd = depth(wx(q.x() + q.w() / 2, q.y() + q.d() / 2), wy(q.x() + q.w() / 2, q.y() + q.d() / 2))
                val col = 0xFF000000.toInt() or Materials.color(q.material())
                val st = stroke(idx, pi)
                val polys = ArrayList<List<PointF>>()
                for (e in 0..3) {
                    val a1 = pc[e]; val b1 = pc[(e + 1) % 4]
                    if (plan || depth((a1.first + b1.first) / 2, (a1.second + b1.second) / 2) <= cd) continue
                    val side = listOf(p(a1.first, a1.second, q.z()), p(b1.first, b1.second, q.z()), p(b1.first, b1.second, q.z() + q.h()), p(a1.first, a1.second, q.z() + q.h()))
                    poly(c, side, shade(col, 0.78f + 0.07f * e), st); polys.add(side)
                }
                val top = pc.map { p(it.first, it.second, q.z() + q.h()) }
                poly(c, top, shade(col, 1.08f), st); texture(c, top, Materials.texture(q.material())); polys.add(top)
                hits.add(Hit(1, idx, pi, polys))
            }
            if (idx == ctl.selected()) { val m = p(f.x(), f.y(), f.height()); c.drawText(f.name(), m.x, m.y, text) }
        }
    }
}
