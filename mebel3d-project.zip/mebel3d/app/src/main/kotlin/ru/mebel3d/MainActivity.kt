package ru.mebel3d

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.*
import mebel3d.core.Building
import mebel3d.core.Catalog
import mebel3d.core.Controller
import mebel3d.core.Core
import mebel3d.core.Drawing
import mebel3d.core.Materials
import mebel3d.core.Photos
import mebel3d.core.Project
import java.io.File

class MainActivity : Activity() {
    private lateinit var building: Building
    private var cur = 0
    private lateinit var ctl: Controller
    private lateinit var scene: SceneView
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var itemButtons: LinearLayout
    private lateinit var title: TextView
    private lateinit var status: TextView
    private val labelViews = ArrayList<TextView>()
    private val fields = ArrayList<EditText>()
    private val rows = ArrayList<LinearLayout>()
    private val prefs by lazy { getSharedPreferences("m3d", MODE_PRIVATE) }
    private val file by lazy { File(filesDir, "building.json") }
    private val variantsDir by lazy { File(filesDir, "variants").apply { mkdirs() } }
    private var pendingExport: String? = null
    private val reqPhoto = 42; private val reqExport = 43; private val reqImport = 44
    private val lightNames = listOf("День", "Вечер", "Ночь")

    // ---------- помощники ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String?) = Toast.makeText(this, t ?: "", Toast.LENGTH_LONG).show()
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }
    private fun guard(block: () -> Unit) { try { block() } catch (e: IllegalArgumentException) { toast(e.message) }; refresh() }
    private fun askChoice(title: String, items: List<String>, onPick: (Int) -> Unit) =
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, i -> onPick(i) }.setNegativeButton("Закрыть", null).show()
    private fun confirm(msg: String, onYes: () -> Unit) =
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Да") { _, _ -> onYes() }.setNegativeButton("Отмена", null).show()
    private fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine() }
        AlertDialog.Builder(this).setTitle(title).setView(et).setPositiveButton("Готово") { _, _ ->
            val s = et.text.toString().trim(); if (s.isEmpty()) toast("Введите название") else onOk(s)
        }.setNegativeButton("Отмена", null).show()
    }
    private fun askNumbers(title: String, hints: List<String>, init: DoubleArray, onOk: (DoubleArray) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val es = hints.mapIndexed { i, h ->
            EditText(this).apply { hint = h; setText(Math.round(init[i]).toString()); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setSingleLine() }.also { box.addView(it) }
        }
        AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Применить") { _, _ ->
            val v = es.map { it.text.toString().toDoubleOrNull() }
            if (v.any { it == null }) toast("Введите числа в миллиметрах") else onOk(v.map { it!! }.toDoubleArray())
        }.setNegativeButton("Отмена", null).show()
    }

    // ---------- проект ----------
    private fun load(): Building {
        try { if (file.exists()) { val b = Building.fromJson(file.readText()); if (b.rooms().isNotEmpty()) return b } } catch (e: Exception) { /* файл повреждён */ }
        try {
            val old = File(filesDir, "project.json")
            if (old.exists()) return Building("Объект", listOf(Building.Placed(Project.fromJson(old.readText()), 0.0, 0.0)))
        } catch (e: Exception) { /* старый файл не читается */ }
        val room = Core.Room(5000.0, 3500.0, 2700.0, 100.0, emptyList())
        return Building("Объект", listOf(Building.Placed(Project("Кухня-гостиная", room, emptyList()), 0.0, 0.0)))
    }
    private fun sync() { building = building.replace(cur, ctl.project()) }
    private fun save() { try { sync(); file.writeText(building.toJson()) } catch (e: Exception) { /* нет места или доступа */ } }
    private fun openRoom(i: Int) { sync(); cur = i; ctl = Controller(building.rooms()[i].project()); scene.ctl = ctl; refresh() }
    private fun replaceBuilding(b: Building) { building = b; cur = 0; ctl = Controller(b.rooms()[0].project()); scene.ctl = ctl; refresh() }

    // ---------- экран ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        building = load(); ctl = Controller(building.rooms()[0].project())
        scene = SceneView(this, ctl) { refresh() }
        scene.grid = prefs.getFloat("grid", 50f).toDouble()

        title = TextView(this).apply { textSize = 15f; setPadding(dp(8), 0, dp(12), 0); gravity = Gravity.CENTER_VERTICAL; setTypeface(typeface, Typeface.BOLD) }
        val top = LinearLayout(this)
        top.addView(title)
        top.addView(btn("Сохранить") { save(); toast("Проект сохранён") })
        top.addView(btn("Отменить") { ctl.undo(); refresh() })
        top.addView(btn("Повторить") { ctl.redo(); refresh() })
        top.addView(btn("2D / 3D") { scene.plan = !scene.plan; scene.invalidate() })
        top.addView(btn("Освещение") { scene.light = (scene.light + 1) % 3; toast(lightNames[scene.light]); scene.invalidate() })
        top.addView(btn("Вид") { viewDialog() })
        top.addView(btn("Настройки") { settingsDialog() })
        top.addView(btn("Экспорт") { drawingsDialog(true) })

        val sections = listOf<Pair<String, () -> Unit>>(
            "🏠\nКомнаты" to { roomsDialog() }, "📐\nПлан" to { planningDialog() }, "🧱\nСтены" to { wallsDialog() },
            "🚪\nДвери" to { openingsDialog() }, "🛋\nМебель" to { catalogDialog() }, "🔧\nДетали" to { constructorDialog() },
            "🎨\nМатериал" to { materialDialog() }, "⚡\nИнженерия" to { engineeringDialog() }, "📏\nЧертежи" to { drawingsDialog(false) },
            "📷\nФото" to { photosDialog() }, "💾\nФайл" to { saveDialog() })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((label, act) in sections) nav.addView(Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false; minHeight = 0; minimumHeight = 0; setPadding(dp(2), dp(4), dp(2), dp(4)); setOnClickListener { act() }
        }, LinearLayout.LayoutParams(dp(66), LinearLayout.LayoutParams.WRAP_CONTENT))

        buildPanel()
        val frame = FrameLayout(this)
        frame.addView(scene, FrameLayout.LayoutParams(-1, -1))
        frame.addView(ScrollView(this).apply { addView(panel) }, FrameLayout.LayoutParams(dp(220), -2, Gravity.END or Gravity.TOP))
        val mid = LinearLayout(this)
        mid.addView(ScrollView(this).apply { addView(nav) }, LinearLayout.LayoutParams(dp(68), -1))
        mid.addView(frame, LinearLayout.LayoutParams(0, -1, 1f))

        status = TextView(this).apply { setPadding(dp(8), 0, dp(8), 0); gravity = Gravity.CENTER_VERTICAL }
        val strip = LinearLayout(this)
        for (n in Catalog.names()) strip.addView(btn(n) { ctl.add(n); refresh() })
        for (kind in Catalog.fixtureKinds()) strip.addView(btn("+ $kind") { ctl.addFixture(kind); refresh() })
        val bottom = LinearLayout(this)
        bottom.addView(status, LinearLayout.LayoutParams(dp(230), -1))
        bottom.addView(HorizontalScrollView(this).apply { addView(strip) }, LinearLayout.LayoutParams(0, -2, 1f))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(HorizontalScrollView(this).apply { addView(top) })
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottom)
        setContentView(root)
        refresh()
    }

    private fun buildPanel() {
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xF2FFFFFF.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8)); visibility = View.GONE }
        panelTitle = TextView(this).apply { textSize = 16f }
        panel.addView(panelTitle)
        repeat(6) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val l = TextView(this)
            val e = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL; setSingleLine(); setText("0") }
            row.addView(l, LinearLayout.LayoutParams(dp(78), LinearLayout.LayoutParams.WRAP_CONTENT)); row.addView(e, LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.WRAP_CONTENT))
            labelViews.add(l); fields.add(e); rows.add(row); panel.addView(row)
        }
        panel.addView(btn("Применить") { apply() })
        itemButtons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        itemButtons.addView(btn("Материал") { materialDialog() })
        itemButtons.addView(btn("Детали") { partsDialog() })
        itemButtons.addView(btn("Копия") { ctl.duplicate(); refresh() })
        itemButtons.addView(btn("Группа…") { groupDialog() })
        panel.addView(itemButtons)
        panel.addView(btn("Удалить") { confirmDelete() })
        panel.addView(btn("Закрыть") { ctl.select(-1); refresh() })
    }

    private fun setRows(labels: List<String>, values: DoubleArray) {
        rows.forEachIndexed { i, r -> r.visibility = if (i < labels.size) View.VISIBLE else View.GONE }
        labels.forEachIndexed { i, l -> labelViews[i].text = l; if (!fields[i].hasFocus()) fields[i].setText(Math.round(values[i]).toString()) }
    }

    private fun refresh() {
        scene.invalidate()
        val kind = ctl.kind()
        panel.visibility = if (kind == 0) View.GONE else View.VISIBLE
        itemButtons.visibility = if (kind == 1) View.VISIBLE else View.GONE
        when (kind) {
            1 -> { val f = ctl.selectedItem(); val g = ctl.project().membersOf(ctl.selected()).size
                panelTitle.text = f.name() + if (g > 1) " (группа: $g)" else ""
                setRows(listOf("Ширина", "Глубина", "Высота", "X", "Y", "Поворот °"), doubleArrayOf(f.width(), f.depth(), f.height(), f.x(), f.y(), f.rot())) }
            2 -> { val o = ctl.selectedOpening()
                panelTitle.text = (if (o.sill() == 0.0) "Дверь" else "Окно") + ", стена ${o.wall() + 1}"
                setRows(listOf("Смещение", "Ширина", "Высота", "От пола"), doubleArrayOf(o.offset(), o.width(), o.height(), o.sill())) }
            3 -> { val x = ctl.selectedFixture(); panelTitle.text = x.kind()
                setRows(listOf("X", "Y", "Ширина", "Глубина", "От пола", "Высота"), doubleArrayOf(x.x(), x.y(), x.w(), x.d(), x.z(), x.h())) }
        }
        title.text = "Мебель 3D · ${ctl.project().name()}"
        val w = ctl.warnings()
        val multi = if (ctl.multi().isNotEmpty()) " · выбрано: ${ctl.multi().size}" else ""
        status.text = if (w.isEmpty()) "мм · ${if (scene.plan) "2D" else "3D"} · предметов: ${ctl.project().items().size}$multi" else "⚠ ${w[0]}$multi"
    }

    private fun apply() {
        try {
            val v = fields.map { it.text.toString().toDouble() }
            when (ctl.kind()) {
                1 -> { ctl.setSize(v[0], v[1], v[2]); ctl.setPosition(v[3], v[4]); ctl.setRotation(v[5]) }
                2 -> ctl.updateOpening(ctl.selectedOpeningIndex(), v[0], v[1], v[2], v[3])
                3 -> ctl.updateFixture(ctl.selectedFixtureIndex(), v[0], v[1], v[2], v[3], v[4], v[5])
            }
        } catch (e: NumberFormatException) { toast("Введите числа в миллиметрах") }
        catch (e: IllegalArgumentException) { toast(e.message ?: "Недопустимый размер") }
        fields.forEach { it.clearFocus() }
        refresh()
    }

    private fun confirmDelete() {
        val what = when (ctl.kind()) { 1 -> "изделие «${ctl.selectedItem().name()}»"; 2 -> "проём"; 3 -> "элемент «${ctl.selectedFixture().kind()}»"; else -> return }
        confirm("Удалить $what? Действие можно отменить кнопкой «Отменить».") { ctl.removeSelected(); refresh() }
    }

    // ---------- 1. Помещения объекта ----------
    private fun roomsDialog() {
        sync()
        val rs = building.rooms()
        val labels = rs.mapIndexed { i, p -> "${if (i == cur) "▶ " else ""}${i + 1}. ${p.project().name()}  ${Math.round(p.project().room().W())}×${Math.round(p.project().room().D())}" } +
            listOf("+ Новое помещение", "План всего объекта", "Связи и площади")
        askChoice("Помещения: ${building.name()}", labels) { i ->
            when (i) {
                rs.size -> newRoomDialog()
                rs.size + 1 -> showSvg("План объекта", Drawing.buildingPlan(building))
                rs.size + 2 -> linksDialog()
                else -> roomActions(i)
            }
        }
    }
    private fun roomActions(i: Int) {
        askChoice(building.rooms()[i].project().name(), listOf("Открыть", "Переименовать", "Положение на общем плане…", "Удалить")) { a ->
            when (a) {
                0 -> openRoom(i)
                1 -> askText("Название помещения", building.rooms()[i].project().name()) { n -> if (i == cur) ctl.rename(n) else building = building.replace(i, building.rooms()[i].project().withName(n)); refresh() }
                2 -> { val r = building.rooms()[i]; askNumbers("Положение на плане, мм", listOf("X", "Y"), doubleArrayOf(r.ox(), r.oy())) { v -> building = building.move(i, v[0], v[1]); refresh() } }
                3 -> if (building.rooms().size == 1) toast("Нельзя удалить единственное помещение")
                     else confirm("Удалить помещение «${building.rooms()[i].project().name()}» со всей мебелью? Вернуть нельзя (кроме сохранённого варианта).") {
                         sync(); building = building.remove(i); val n = if (cur > i) cur - 1 else if (cur == i) 0 else cur; cur = n
                         ctl = Controller(building.rooms()[n].project()); scene.ctl = ctl; refresh() }
            }
        }
    }
    private fun newRoomDialog() {
        askText("Название нового помещения", "Помещение ${building.rooms().size + 1}") { name ->
            askNumbers("Размеры, мм", listOf("Ширина", "Глубина", "Высота стен", "Толщина стен"), doubleArrayOf(4000.0, 3000.0, 2700.0, 100.0)) { v ->
                try {
                    val room = Core.Room(v[0], v[1], v[2], v[3], emptyList())
                    if (v.any { it <= 0 } || 2 * v[3] >= minOf(v[0], v[1])) throw IllegalArgumentException("Недопустимые размеры помещения")
                    val o = building.nextFreeOrigin(v[0], v[1], v[3])
                    sync(); building = building.add(Project(name, room, emptyList()), o[0], o[1]); openRoom(building.rooms().size - 1)
                } catch (e: IllegalArgumentException) { toast(e.message) }
            }
        }
    }
    private fun linksDialog() {
        sync()
        val sb = StringBuilder("Общая площадь: ${"%.1f".format(building.totalAreaM2())} м²\nПомещений: ${building.rooms().size}\n\nСоседи (общая стена):\n")
        building.neighbors().ifEmpty { listOf("нет") }.forEach { sb.append("  $it\n") }
        sb.append("\nПроходы (двери в общей стене):\n"); building.passages().ifEmpty { listOf("нет") }.forEach { sb.append("  $it\n") }
        sb.append("\nПредупреждения:\n"); building.warnings().ifEmpty { listOf("нет") }.forEach { sb.append("  $it\n") }
        showText("Связи помещений", sb.toString())
    }

    // ---------- 2–4. Планировка, стены, двери и окна ----------
    private fun roomSizeDialog() {
        val r = ctl.project().room()
        askNumbers("Помещение", listOf("Ширина, мм", "Глубина, мм", "Высота стен, мм", "Толщина стен, мм"), doubleArrayOf(r.W(), r.D(), r.H(), r.wallT())) { v -> guard { ctl.setRoom(v[0], v[1], v[2], v[3]) } }
    }
    private fun planningDialog() {
        askChoice("Планировка", listOf("Размеры комнаты…", "Вид сверху / 3D", "Проверка проекта", "Шаг привязки к сетке: ${scene.grid.toInt()} мм")) { i ->
            when (i) {
                0 -> roomSizeDialog()
                1 -> { scene.plan = !scene.plan; refresh() }
                2 -> showText("Проверка проекта", ctl.warnings().ifEmpty { listOf("Замечаний нет") }.joinToString("\n"))
                3 -> gridDialog()
            }
        }
    }
    private fun gridDialog() {
        val steps = listOf(10, 50, 100)
        askChoice("Шаг сетки", steps.map { "$it мм" }) { i -> scene.grid = steps[i].toDouble(); prefs.edit().putFloat("grid", steps[i].toFloat()).apply(); refresh() }
    }
    private fun wallsDialog() {
        askChoice("Стены и проёмы", listOf("Видимость стен…", "Размеры и толщина стен…", "Выбрать проём для правки…")) { i ->
            when (i) { 0 -> wallVisibilityDialog(); 1 -> roomSizeDialog(); 2 -> pickOpening() }
        }
    }
    private fun wallVisibilityDialog() {
        val names = listOf("авто", "скрыта", "прозрачная", "видна")
        askChoice("Видимость стен (касание — сменить)", (0..3).map { "Стена ${it + 1}: ${names[scene.wallState[it]]}" }) { i ->
            scene.wallState[i] = (scene.wallState[i] + 1) % 4; scene.invalidate(); wallVisibilityDialog()
        }
    }
    private fun pickOpening() {
        val os = ctl.project().room().openings()
        if (os.isEmpty()) return toast("Проёмов нет")
        askChoice("Проёмы", os.mapIndexed { i, o -> "${i + 1}. ${if (o.sill() == 0.0) "Дверь" else "Окно"}, стена ${o.wall() + 1}, ${Math.round(o.width())}×${Math.round(o.height())}" }) { i -> ctl.selectOpening(i); refresh() }
    }
    private fun openingsDialog() {
        askChoice("Двери и окна", listOf("+ Окно", "+ Дверь", "Выбрать проём для правки…")) { i ->
            when (i) { 0 -> { if (!ctl.addOpening("Окно")) toast("На стенах нет свободного места"); refresh() }
                       1 -> { if (!ctl.addOpening("Дверь")) toast("На стенах нет свободного места"); refresh() }
                       2 -> pickOpening() }
        }
    }

    // ---------- 5. Каталог ----------
    private fun catalogDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        val q = EditText(this).apply { hint = "Поиск мебели…"; setSingleLine() }
        var cat: String? = null
        val catBtn = btn("Категория: все") { }
        val list = ListView(this)
        var shown: List<String> = emptyList()
        fun fill() { shown = Catalog.search(q.text.toString(), cat); list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown) }
        catBtn.setOnClickListener {
            val cats = listOf("все") + Catalog.categories()
            AlertDialog.Builder(this).setTitle("Категория").setItems(cats.toTypedArray()) { _, i -> cat = if (i == 0) null else cats[i]; catBtn.text = "Категория: ${cats[i]}"; fill() }.show()
        }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        box.addView(q); box.addView(catBtn); box.addView(list, LinearLayout.LayoutParams(-1, dp(220)))
        val dlg = AlertDialog.Builder(this).setTitle("Каталог мебели").setView(box).setNegativeButton("Закрыть", null).create()
        list.setOnItemClickListener { _, _, i, _ -> ctl.add(shown[i]); dlg.dismiss(); refresh() }
        fill(); dlg.show()
    }

    // ---------- 6. Конструктор, группы ----------
    private fun constructorDialog() {
        askChoice("Конструктор деталей", listOf("Режим деталей: ${if (scene.partMode) "включён" else "выключен"}", "Детали выбранного изделия…", "Новая заготовка (панель)")) { i ->
            when (i) {
                0 -> { scene.partMode = !scene.partMode; toast(if (scene.partMode) "Касание выбирает деталь выбранного изделия" else "Касание переносит изделие"); refresh() }
                1 -> partsDialog()
                2 -> { ctl.add("Панель"); refresh() }
            }
        }
    }
    private fun groupDialog() {
        askChoice("Группа", listOf("Выбор нескольких: ${if (scene.multiMode) "включён" else "выключен"}", "Сгруппировать выбранные", "Разгруппировать выбранное изделие")) { i ->
            when (i) {
                0 -> { scene.multiMode = !scene.multiMode; ctl.clearMulti(); toast(if (scene.multiMode) "Касайтесь изделий, затем «Сгруппировать»" else "Обычный режим"); refresh() }
                1 -> guard { ctl.groupMulti("Группа ${ctl.project().groups().size + 1}"); scene.multiMode = false }
                2 -> guard { ctl.ungroupSelected() }
            }
        }
    }
    private fun partsDialog() {
        val f = ctl.selectedItem() ?: return toast("Сначала выберите изделие")
        val labels = f.parts().mapIndexed { i, q -> "${i + 1}. ${q.name()}  ${Math.round(q.w())}×${Math.round(q.d())}×${Math.round(q.h())}" } + "+ Добавить деталь"
        AlertDialog.Builder(this).setTitle("Детали: ${f.name()}").setItems(labels.toTypedArray()) { _, i ->
            if (i == f.parts().size) partEditor(-1) else { ctl.selectPart(i); partEditor(i); refresh() }
        }.setNegativeButton("Закрыть", null).show()
    }
    private fun partEditor(i: Int) {
        val f = ctl.selectedItem() ?: return
        val q = if (i >= 0) f.parts()[i] else null
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val nameField = EditText(this).apply { hint = "Название"; setText(q?.name() ?: "Деталь"); setSingleLine() }
        box.addView(nameField)
        val hints = listOf("Ширина (X), мм", "Глубина (Y), мм", "Высота (Z), мм", "Положение X, мм", "Положение Y, мм", "Положение Z, мм")
        val init = if (q != null) doubleArrayOf(q.w(), q.d(), q.h(), q.x(), q.y(), q.z()) else doubleArrayOf(600.0, 400.0, 18.0, 0.0, 0.0, 0.0)
        val es = hints.mapIndexed { k, h ->
            EditText(this).apply { hint = h; setText(Math.round(init[k]).toString()); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setSingleLine() }.also { box.addView(it) }
        }
        val linked = CheckBox(this).apply { text = "Связанное изменение размеров (соседние детали подстраиваются)"; isChecked = true }
        if (q != null) box.addView(linked)
        var mat: String = q?.material() ?: Materials.dominant(f)
        val matBtn = btn("Материал: $mat") { }
        matBtn.setOnClickListener {
            val names = Materials.names().toTypedArray()
            AlertDialog.Builder(this).setTitle("Материал детали").setItems(names) { _, k -> mat = names[k]; matBtn.text = "Материал: $mat" }.show()
        }
        box.addView(matBtn)
        val dlg = AlertDialog.Builder(this).setTitle(if (q == null) "Новая деталь" else q.name()).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Применить", null).setNegativeButton("Закрыть", null).create()
        if (q != null) {
            box.addView(btn("Копия детали") { try { ctl.duplicatePart(q.w(), 0.0, 0.0) } catch (e: IllegalArgumentException) { toast(e.message) }; dlg.dismiss(); refresh() })
            box.addView(btn("Удалить деталь (можно отменить)") { try { ctl.removePart() } catch (e: IllegalArgumentException) { toast(e.message) }; dlg.dismiss(); refresh() })
        }
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            try {
                val v = es.map { it.text.toString().toDouble() }
                if (q == null) ctl.addPart(nameField.text.toString(), v[0], v[1], v[2], v[3], v[4], v[5], mat)
                else {
                    for (a in 0..2) if (v[a] != init[a]) ctl.setPartSize(a, v[a], linked.isChecked)
                    if (v[3] != init[3] || v[4] != init[4] || v[5] != init[5]) ctl.setPartPosition(v[3], v[4], v[5])
                    if (mat != q.material()) ctl.setPartMaterial(mat)
                }
                dlg.dismiss(); refresh()
            } catch (e: NumberFormatException) { toast("Введите числа в миллиметрах") }
            catch (e: IllegalArgumentException) { toast(e.message) }
        }
    }

    // ---------- 7–8. Материалы, инженерия ----------
    private fun materialDialog() {
        if (ctl.selectedItem() == null) return toast("Сначала выберите изделие")
        val names = Materials.names()
        askChoice("Материал изделия", names) { i -> guard { ctl.setMaterial(names[i]) } }
    }
    private fun engineeringDialog() {
        val kinds = Catalog.fixtureKinds()
        askChoice("Инженерные элементы", kinds.map { "+ $it" } + "Выбрать элемент для правки…") { i ->
            if (i < kinds.size) { ctl.addFixture(kinds[i]); refresh() }
            else {
                val fx = ctl.project().fixtures()
                if (fx.isEmpty()) toast("Элементов нет")
                else askChoice("Элементы", fx.mapIndexed { k, x -> "${k + 1}. ${x.kind()} (${Math.round(x.x())}, ${Math.round(x.y())})" }) { k -> ctl.selectFixture(k); refresh() }
            }
        }
    }

    // ---------- 9. Чертежи и экспорт ----------
    private fun drawingsDialog(export: Boolean) {
        sync()
        val p = ctl.project()
        val items = listOf("План комнаты", "План всего объекта", "Развёртка: стена 1", "Развёртка: стена 2", "Развёртка: стена 3", "Развёртка: стена 4",
            "Спецификация и ведомость материалов", "Чертёж выбранного изделия") + if (export) emptyList() else listOf("Сохранить всё в файлы")
        askChoice(if (export) "Экспорт" else "Чертежи", items) { i ->
            val f = ctl.selectedItem()
            val r: Triple<String, String, String>? = when (i) {
                0 -> Triple(items[0], Drawing.plan(p), "plan.svg")
                1 -> Triple(items[1], Drawing.buildingPlan(building), "plan-obekta.svg")
                2, 3, 4, 5 -> Triple(items[i], Drawing.elevation(p, i - 2), "razvertka-${i - 1}.svg")
                6 -> Triple(items[6], Drawing.specification(p), "specifikaciya.txt")
                7 -> if (f == null) { toast("Сначала выберите изделие"); null } else Triple(f.name(), Drawing.furniture(f), "izdelie.svg")
                else -> { saveAll(); null }
            }
            if (r != null) {
                if (export) exportText(r.third, if (r.third.endsWith(".svg")) "image/svg+xml" else "text/plain", r.second)
                else if (r.third.endsWith(".svg")) showSvg(r.first, r.second) else showText(r.first, r.second)
            }
        }
    }
    private fun showSvg(title: String, svg: String) {
        val web = WebView(this).apply {
            settings.builtInZoomControls = true; settings.displayZoomControls = false; settings.useWideViewPort = true; settings.loadWithOverviewMode = true
            loadDataWithBaseURL(null, "<html><body style='margin:0;background:#fff'>$svg</body></html>", "text/html", "utf-8", null)
        }
        AlertDialog.Builder(this).setTitle(title).setView(web).setPositiveButton("Закрыть", null).show()
    }
    private fun showText(title: String, text: String) {
        val tv = TextView(this).apply { this.text = text; typeface = Typeface.MONOSPACE; textSize = 12f; setPadding(dp(12), dp(8), dp(12), dp(8)); setTextIsSelectable(true) }
        AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(tv) }).setPositiveButton("Закрыть", null).show()
    }
    private fun saveAll() {
        val dir = File(getExternalFilesDir(null) ?: filesDir, "drawings").apply { mkdirs() }
        try {
            val p = ctl.project()
            File(dir, "plan.svg").writeText(Drawing.plan(p)); File(dir, "plan-obekta.svg").writeText(Drawing.buildingPlan(building))
            for (w in 0..3) File(dir, "razvertka-${w + 1}.svg").writeText(Drawing.elevation(p, w))
            File(dir, "specifikaciya.txt").writeText(Drawing.specification(p))
            p.items().forEachIndexed { i, f -> File(dir, "izdelie-${i + 1}.svg").writeText(Drawing.furniture(f)) }
            toast("Сохранено в ${dir.absolutePath}")
        } catch (e: Exception) { toast("Не удалось сохранить: ${e.message}") }
    }
    private fun exportText(name: String, mime: String, content: String) {
        pendingExport = content
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }, reqExport)
    }

    // ---------- 11. Сохранение, варианты ----------
    private fun saveDialog() {
        askChoice("Сохранение", listOf("Сохранить сейчас", "Сохранить вариант проекта…", "Загрузить вариант…", "Экспорт проекта в файл…", "Импорт проекта из файла…")) { i ->
            when (i) {
                0 -> { save(); toast("Проект сохранён") }
                1 -> askText("Название варианта", "Вариант ${(variantsDir.list()?.size ?: 0) + 1}") { n ->
                    sync(); try { File(variantsDir, n.replace(Regex("[^\\p{L}\\p{N} _-]"), "_") + ".json").writeText(building.toJson()); toast("Вариант сохранён") } catch (e: Exception) { toast("Не удалось сохранить: ${e.message}") } }
                2 -> { val fs = variantsDir.listFiles()?.sortedBy { it.name }.orEmpty()
                    if (fs.isEmpty()) toast("Сохранённых вариантов нет")
                    else askChoice("Варианты", fs.map { it.nameWithoutExtension }) { k ->
                        confirm("Текущий проект будет заменён вариантом «${fs[k].nameWithoutExtension}». Сначала сохраните текущий как вариант, если он нужен.") {
                            try { replaceBuilding(Building.fromJson(fs[k].readText())) } catch (e: Exception) { toast("Файл варианта повреждён") } } } }
                3 -> { sync(); exportText("mebel3d-project.json", "application/json", building.toJson()) }
                4 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, reqImport)
            }
        }
    }

    // ---------- вид и настройки ----------
    private fun viewDialog() {
        askChoice("Вид", listOf("Стандартный вид", "Видимость стен…", "Вид сверху / 3D")) { i ->
            when (i) { 0 -> scene.resetView(); 1 -> wallVisibilityDialog(); 2 -> { scene.plan = !scene.plan; refresh() } }
        }
    }
    private fun settingsDialog() {
        askChoice("Настройки", listOf("Шаг привязки к сетке: ${scene.grid.toInt()} мм", "Единицы: миллиметры, тема: светлая", "О программе")) { i ->
            when (i) { 0 -> gridDialog(); 2 -> showText("О программе", "Мебель 3D, версия 0.1\nГеометрическое ядро проверено тестами; интерфейс Android проверяется владельцем.\nКамера: вращение пальцем, масштаб щипком.") }
        }
    }

    // ---------- результаты системных окон ----------
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            reqPhoto -> {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { /* доступ только на этот запуск */ }
                ctl.addPhoto("Фото ${ctl.photos().size + 1}", uri.toString()); openPhoto(ctl.photos().size - 1)
            }
            reqExport -> try { contentResolver.openOutputStream(uri)?.use { it.write((pendingExport ?: "").toByteArray(Charsets.UTF_8)) }; toast("Файл сохранён") }
                catch (e: Exception) { toast("Не удалось сохранить: ${e.message}") }
            reqImport -> try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: throw IllegalArgumentException("Файл пуст")
                replaceBuilding(if (text.contains("\"rooms\"")) Building.fromJson(text) else Building("Объект", listOf(Building.Placed(Project.fromJson(text), 0.0, 0.0))))
                toast("Проект загружен")
            } catch (e: Exception) { toast("Не удалось открыть файл проекта: ${e.message}") }
        }
    }

    // ---------- 10. Фото помещения ----------
    private fun photosDialog() {
        val ph = ctl.photos()
        val labels = ph.mapIndexed { i, p ->
            "${i + 1}. ${p.name()} · " + (if (p.bound()) "стена ${p.wall() + 1}" else "не привязано") + " · " + (if (p.calibrated()) "масштаб задан" else "без масштаба") + " · отметок: ${p.marks().size}"
        } + "+ Добавить фото"
        askChoice("Фото помещения", labels) { i ->
            if (i == ph.size) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, reqPhoto)
            else openPhoto(i)
        }
    }
    private fun loadBitmap(uri: String): Pair<Bitmap, Double>? = try {
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        if (bmp == null || bounds.outWidth <= 0) null else Pair(bmp, bounds.outWidth.toDouble() / bmp.width)
    } catch (e: Exception) { null }

    private fun openPhoto(i: Int) {
        val loaded = loadBitmap(ctl.photos()[i].uri()) ?: return toast("Не удалось открыть снимок. Добавьте его заново")
        val dlg = Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        val view = PhotoView(this, loaded.first, loaded.second)
        val hint = TextView(this).apply { setPadding(dp(8), dp(4), dp(8), dp(4)); text = "Выберите действие вверху" }
        fun show() { view.photo = ctl.photos()[i]; view.invalidate() }
        fun photoGuard(block: () -> Unit) { try { block() } catch (e: IllegalArgumentException) { toast(e.message) }; show() }
        view.onPick = { tool, x1, y1, x2, y2 ->
            when (tool) {
                1 -> askNumbers("Расстояние между точками, мм", listOf("мм"), doubleArrayOf(1000.0)) { v -> photoGuard { ctl.calibratePhoto(i, x1, y1, x2, y2, v[0]) } }
                2 -> askChoice("К какой стене относится снимок?", listOf("Стена 1", "Стена 2", "Стена 3", "Стена 4")) { w -> photoGuard { ctl.bindPhoto(i, w, x1, y1) } }
                3 -> askChoice("Что отмечено?", Photos.markKinds()) { k -> photoGuard { ctl.addMark(i, Photos.markKinds()[k], x1, y1, x2, y2) } }
            }
        }
        val bar = LinearLayout(this)
        bar.addView(btn("Масштаб") { view.tool = 1; hint.text = "Коснитесь двух точек на стене, расстояние между которыми известно" })
        bar.addView(btn("Угол и пол") { view.tool = 2; hint.text = "Коснитесь точки, где левый край стены встречается с полом" })
        bar.addView(btn("Отметка") { view.tool = 3; hint.text = "Обведите рамкой окно, дверь или коммуникацию" })
        bar.addView(btn("В модель") {
            val marks = ctl.photos()[i].marks()
            if (marks.isEmpty()) toast("Сначала поставьте отметки")
            else askChoice("Перенести отметку в комнату", marks.mapIndexed { k, m -> "${k + 1}. ${m.kind()}" }) { k -> photoGuard { ctl.applyMark(i, k); toast("Добавлено в модель"); refresh() } }
        })
        bar.addView(btn("Удалить отметку") {
            val marks = ctl.photos()[i].marks()
            if (marks.isNotEmpty()) askChoice("Удалить отметку", marks.mapIndexed { k, m -> "${k + 1}. ${m.kind()}" }) { k -> photoGuard { ctl.removeMark(i, k) } }
        })
        bar.addView(btn("Закрыть") { dlg.dismiss(); refresh() })
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(HorizontalScrollView(this).apply { addView(bar) }); root.addView(hint); root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        dlg.setContentView(root); show(); dlg.show()
    }

    override fun onPause() { super.onPause(); save() }
}
