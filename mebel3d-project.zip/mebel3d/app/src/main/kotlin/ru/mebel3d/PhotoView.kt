package ru.mebel3d

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import mebel3d.core.Photos
import kotlin.math.max
import kotlin.math.min

/** Снимок как подложка с разметкой. Координаты наружу — в пикселях исходного снимка (умножены на srcScale). */
class PhotoView(ctx: Context, private val bmp: Bitmap, private val srcScale: Double) : View(ctx) {
    /** 0 — просмотр, 1 — калибровка (две точки), 2 — угол стены на полу (точка), 3 — отметка (рамка). */
    var tool = 0
        set(v) { field = v; first = null; dragA = null; dragB = null; invalidate() }
    var photo: Photos.Photo? = null
    var onPick: (Int, Double, Double, Double, Double) -> Unit = { _, _, _, _, _ -> }
    private var s = 1f; private var tx = 0f; private var ty = 0f
    private var first: PointF? = null
    private var dragA: PointF? = null
    private var dragB: PointF? = null
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF1F6FFF.toInt() }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFFFF8A00.toInt() }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; color = 0xFFFF8A00.toInt() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD23B3B.toInt() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        s = min(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        tx = (w - bmp.width * s) / 2; ty = (h - bmp.height * s) / 2
    }
    private fun toImg(x: Float, y: Float) = PointF((x - tx) / s, (y - ty) / s)
    private fun toView(ox: Double, oy: Double) = PointF((ox / srcScale * s + tx).toFloat(), (oy / srcScale * s + ty).toFloat())
    private fun inside(p: PointF) = p.x >= 0 && p.y >= 0 && p.x <= bmp.width && p.y <= bmp.height

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (tool == 0) return true
        val p = toImg(e.x, e.y)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (tool == 3 && inside(p)) { dragA = p; dragB = p }
            MotionEvent.ACTION_MOVE -> if (tool == 3 && dragA != null) { dragB = p; invalidate() }
            MotionEvent.ACTION_UP -> {
                if (!inside(p)) return true
                val k = srcScale
                when (tool) {
                    1 -> { val f = first; if (f == null) { first = p; invalidate() } else { first = null; onPick(1, f.x * k, f.y * k, p.x * k, p.y * k); invalidate() } }
                    2 -> onPick(2, p.x * k, p.y * k, 0.0, 0.0)
                    3 -> { val a = dragA; if (a != null) { onPick(3, a.x * k, a.y * k, p.x * k, p.y * k); dragA = null; dragB = null; invalidate() } }
                }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF222222.toInt())
        c.save(); c.translate(tx, ty); c.scale(s, s); c.drawBitmap(bmp, 0f, 0f, null); c.restore()
        val ph = photo
        if (ph != null) {
            if (ph.calibrated()) {
                val a = toView(ph.calAx(), ph.calAy()); val b = toView(ph.calBx(), ph.calBy())
                c.drawLine(a.x, a.y, b.x, b.y, line); c.drawCircle(a.x, a.y, 8f, dot); c.drawCircle(b.x, b.y, 8f, dot)
                c.drawText("${Math.round(ph.knownMm())} мм", (a.x + b.x) / 2, (a.y + b.y) / 2 - 12, label)
            }
            if (ph.bound()) {
                val o = toView(ph.originX(), ph.floorY())
                c.drawLine(o.x, 0f, o.x, height.toFloat(), line); c.drawLine(0f, o.y, width.toFloat(), o.y, line)
                c.drawText("стена ${ph.wall() + 1}", o.x + 8, o.y - 8, label)
            }
            ph.marks().forEachIndexed { i, m ->
                val a = toView(m.x1(), m.y1()); val b = toView(m.x2(), m.y2())
                c.drawRect(a.x, a.y, b.x, b.y, mark); c.drawText("${i + 1}. ${m.kind()}", a.x + 6, a.y + 32, label)
            }
        }
        first?.let { c.drawCircle(it.x * s + tx, it.y * s + ty, 10f, dot) }
        val a = dragA; val b = dragB
        if (a != null && b != null) c.drawRect(a.x * s + tx, a.y * s + ty, b.x * s + tx, b.y * s + ty, mark)
    }
}
